package b4j.example.designerscripts;
import anywheresoftware.b4a.BA;


public class LS_pane1{

public static void LS_general(anywheresoftware.b4a.BA ba, javafx.scene.Node parent, anywheresoftware.b4j.objects.LayoutValues lv,
anywheresoftware.b4j.objects.LayoutBuilder.LayoutData views, int width, int height, float scale)  throws Exception  {
;
//BA.debugLineNum = 2;BA.debugLine="btnPane1.HorizontalCenter = 50%x"[Pane1/General script]
views.get("btnpane1").setLeft((int)((50d / 100 * width) - (views.get("btnpane1").getPrefWidth() / 2)));
//BA.debugLineNum = 3;BA.debugLine="btnPane1.VerticalCenter = 50%y"[Pane1/General script]
views.get("btnpane1").setTop((int)((50d / 100 * height) - (views.get("btnpane1").getPrefHeight() / 2)));

}
}