package b4j.example.designerscripts;
import anywheresoftware.b4a.BA;


public class LS_paneg1{

public static void LS_general(anywheresoftware.b4a.BA ba, javafx.scene.Node parent, anywheresoftware.b4j.objects.LayoutValues lv,
anywheresoftware.b4j.objects.LayoutBuilder.LayoutData views, int width, int height, float scale)  throws Exception  {
;
views.get("btnpaneg1").setLeft((int)((50d / 100 * width) - (views.get("btnpaneg1").getPrefWidth() / 2)));
//BA.debugLineNum = 3;BA.debugLine="btnPaneG1.VerticalCenter = 50%y"[PaneG1/General script]
views.get("btnpaneg1").setTop((int)((50d / 100 * height) - (views.get("btnpaneg1").getPrefHeight() / 2)));

}
}