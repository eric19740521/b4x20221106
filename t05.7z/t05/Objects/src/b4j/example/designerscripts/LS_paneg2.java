package b4j.example.designerscripts;
import anywheresoftware.b4a.BA;


public class LS_paneg2{

public static void LS_general(anywheresoftware.b4a.BA ba, javafx.scene.Node parent, anywheresoftware.b4j.objects.LayoutValues lv,
anywheresoftware.b4j.objects.LayoutBuilder.LayoutData views, int width, int height, float scale)  throws Exception  {
;
views.get("btnpaneg2").setLeft((int)((50d / 100 * width) - (views.get("btnpaneg2").getPrefWidth() / 2)));
//BA.debugLineNum = 3;BA.debugLine="btnPaneG2.VerticalCenter = 50%y"[PaneG2/General script]
views.get("btnpaneg2").setTop((int)((50d / 100 * height) - (views.get("btnpaneg2").getPrefHeight() / 2)));

}
}