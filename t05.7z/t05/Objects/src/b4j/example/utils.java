package b4j.example;


import anywheresoftware.b4a.BA;

public class utils extends Object{
public static utils mostCurrent = new utils();

public static BA ba;
static {
		ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.utils", null);
		ba.loadHtSubs(utils.class);
        if (ba.getClass().getName().endsWith("ShellBA")) {
			
			ba.raiseEvent2(null, true, "SHELL", false);
			ba.raiseEvent2(null, true, "CREATE", true, "b4j.example.utils", ba);
		}
	}
    public static Class<?> getObject() {
		return utils.class;
	}

 public static anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4j.objects.JFX _fx = null;
public static int[] _alltextsizes = null;
public static int _alltextcount = 0;
public static int _multiplyform = 0;
public static b4j.example.dateutils _dateutils = null;
public static b4j.example.cssutils _cssutils = null;
public static b4j.example.main _main = null;
public static b4j.example.xuiviewsutils _xuiviewsutils = null;
public static String  _controletab(Object _ctl) throws Exception{
anywheresoftware.b4j.agraham.reflection.Reflection _r = null;
 //BA.debugLineNum = 131;BA.debugLine="Public Sub ControleTab(ctl As Object)";
 //BA.debugLineNum = 133;BA.debugLine="Dim r As Reflector";
_r = new anywheresoftware.b4j.agraham.reflection.Reflection();
 //BA.debugLineNum = 134;BA.debugLine="r.Target = ctl";
_r.Target = _ctl;
 //BA.debugLineNum = 135;BA.debugLine="r.AddEventFilter(\"keypressed\",\"javafx.scene.input";
_r.AddEventFilter(ba,"keypressed","javafx.scene.input.KeyEvent.KEY_PRESSED");
 //BA.debugLineNum = 136;BA.debugLine="End Sub";
return "";
}
public static b4j.example.main._point  _createpoint(anywheresoftware.b4j.objects.NodeWrapper.MouseEventWrapper _ed) throws Exception{
b4j.example.main._point _thepoints = null;
 //BA.debugLineNum = 153;BA.debugLine="Sub CreatePoint (ED As MouseEvent) As Point";
 //BA.debugLineNum = 154;BA.debugLine="Dim thepoints As Point";
_thepoints = new b4j.example.main._point();
 //BA.debugLineNum = 155;BA.debugLine="thepoints.Initialize";
_thepoints.Initialize();
 //BA.debugLineNum = 156;BA.debugLine="thepoints.x = ED.X";
_thepoints.x /*double*/  = _ed.getX();
 //BA.debugLineNum = 157;BA.debugLine="thepoints.y = ED.y";
_thepoints.y /*double*/  = _ed.getY();
 //BA.debugLineNum = 158;BA.debugLine="Return thepoints";
if (true) return _thepoints;
 //BA.debugLineNum = 159;BA.debugLine="End Sub";
return null;
}
public static String  _getcolorrgb(anywheresoftware.b4j.objects.JFX.PaintWrapper _colorvalue) throws Exception{
String _result = "";
anywheresoftware.b4j.object.JavaObject _jocv = null;
double _r = 0;
double _g = 0;
double _b = 0;
 //BA.debugLineNum = 164;BA.debugLine="Sub GetColorRGB(ColorValue As Paint) As String";
 //BA.debugLineNum = 165;BA.debugLine="Dim result As String = \"\"";
_result = "";
 //BA.debugLineNum = 166;BA.debugLine="Dim joCV As JavaObject = ColorValue";
_jocv = new anywheresoftware.b4j.object.JavaObject();
_jocv = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_colorvalue.getObject()));
 //BA.debugLineNum = 167;BA.debugLine="Dim R As Double = joCV.RunMethod(\"getRed\", Null)";
_r = (double)(BA.ObjectToNumber(_jocv.RunMethod("getRed",(Object[])(anywheresoftware.b4a.keywords.Common.Null))));
 //BA.debugLineNum = 168;BA.debugLine="Dim G As Double = joCV.RunMethod(\"getGreen\", Null";
_g = (double)(BA.ObjectToNumber(_jocv.RunMethod("getGreen",(Object[])(anywheresoftware.b4a.keywords.Common.Null))));
 //BA.debugLineNum = 169;BA.debugLine="Dim B As Double = joCV.RunMethod(\"getBlue\", Null)";
_b = (double)(BA.ObjectToNumber(_jocv.RunMethod("getBlue",(Object[])(anywheresoftware.b4a.keywords.Common.Null))));
 //BA.debugLineNum = 170;BA.debugLine="result = Round(R * 255) & \"-\" & Round(G * 255) &";
_result = BA.NumberToString(anywheresoftware.b4a.keywords.Common.Round(_r*255))+"-"+BA.NumberToString(anywheresoftware.b4a.keywords.Common.Round(_g*255))+"-"+BA.NumberToString(anywheresoftware.b4a.keywords.Common.Round(_b*255));
 //BA.debugLineNum = 171;BA.debugLine="Return result";
if (true) return _result;
 //BA.debugLineNum = 172;BA.debugLine="End Sub";
return "";
}
public static String  _keypressed_filter(anywheresoftware.b4j.objects.NodeWrapper.ConcreteEventWrapper _e) throws Exception{
anywheresoftware.b4j.object.JavaObject _jo = null;
String _keycode = "";
 //BA.debugLineNum = 139;BA.debugLine="Sub KeyPressed_Filter (e As Event)";
 //BA.debugLineNum = 140;BA.debugLine="Log(e)";
anywheresoftware.b4a.keywords.Common.LogImpl("53276801",BA.ObjectToString(_e),0);
 //BA.debugLineNum = 142;BA.debugLine="Dim jo As JavaObject = e";
_jo = new anywheresoftware.b4j.object.JavaObject();
_jo = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_e.getObject()));
 //BA.debugLineNum = 143;BA.debugLine="Dim keycode As String = jo.RunMethod(\"getCode\", N";
_keycode = BA.ObjectToString(_jo.RunMethod("getCode",(Object[])(anywheresoftware.b4a.keywords.Common.Null)));
 //BA.debugLineNum = 144;BA.debugLine="If keycode = \"TAB\" Then";
if ((_keycode).equals("TAB")) { 
 //BA.debugLineNum = 145;BA.debugLine="Log(\"tab\")";
anywheresoftware.b4a.keywords.Common.LogImpl("53276806","tab",0);
 }else {
 //BA.debugLineNum = 147;BA.debugLine="Log(\"KeyPressed_Filter: \"&keycode)";
anywheresoftware.b4a.keywords.Common.LogImpl("53276808","KeyPressed_Filter: "+_keycode,0);
 //BA.debugLineNum = 148;BA.debugLine="e.Consume";
_e.Consume();
 };
 //BA.debugLineNum = 150;BA.debugLine="End Sub";
return "";
}
public static b4j.example.main._textmetric  _measuretext(String _text,anywheresoftware.b4j.objects.JFX.FontWrapper _tfont) throws Exception{
b4j.example.main._textmetric _tm = null;
anywheresoftware.b4j.object.JavaObject _t = null;
 //BA.debugLineNum = 28;BA.debugLine="Sub MeasureText(Text As String,TFont As Font) As T";
 //BA.debugLineNum = 29;BA.debugLine="Dim TM As TextMetric";
_tm = new b4j.example.main._textmetric();
 //BA.debugLineNum = 30;BA.debugLine="TM.Initialize";
_tm.Initialize();
 //BA.debugLineNum = 31;BA.debugLine="Dim T As JavaObject";
_t = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 32;BA.debugLine="T.InitializeNewInstance(\"javafx.scene.text.Text\",";
_t.InitializeNewInstance("javafx.scene.text.Text",new Object[]{(Object)(_text)});
 //BA.debugLineNum = 33;BA.debugLine="T.RunMethod(\"setFont\",Array(TFont))";
_t.RunMethod("setFont",new Object[]{(Object)(_tfont.getObject())});
 //BA.debugLineNum = 34;BA.debugLine="TM.Width = T.RunMethod(\"prefWidth\",Array(-1.0))";
_tm.Width /*double*/  = (double)(BA.ObjectToNumber(_t.RunMethod("prefWidth",new Object[]{(Object)(-1.0)})));
 //BA.debugLineNum = 35;BA.debugLine="TM.Height = T.RunMethod(\"prefHeight\",Array(TM.Wid";
_tm.Height /*double*/  = (double)(BA.ObjectToNumber(_t.RunMethod("prefHeight",new Object[]{(Object)(_tm.Width /*double*/ )})));
 //BA.debugLineNum = 36;BA.debugLine="Return TM";
if (true) return _tm;
 //BA.debugLineNum = 37;BA.debugLine="End Sub";
return null;
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 2;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 3;BA.debugLine="Private fx As JFX";
_fx = new anywheresoftware.b4j.objects.JFX();
 //BA.debugLineNum = 6;BA.debugLine="Dim alltextsizes(1000) As Int, alltextcount As In";
_alltextsizes = new int[(int) (1000)];
;
_alltextcount = (int) (0);
 //BA.debugLineNum = 8;BA.debugLine="Public multiplyform As Int = 1";
_multiplyform = (int) (1);
 //BA.debugLineNum = 14;BA.debugLine="End Sub";
return "";
}
public static String  _randomstring(int _length) throws Exception{
String _abc = "";
String _randomstr = "";
int _i = 0;
 //BA.debugLineNum = 17;BA.debugLine="Sub RandomString(length As Int) As String";
 //BA.debugLineNum = 18;BA.debugLine="Dim abc As String = \"0123456789ABCDEFGHIJKLMNOPQR";
_abc = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
 //BA.debugLineNum = 19;BA.debugLine="Dim RandomStr As String = \"\"";
_randomstr = "";
 //BA.debugLineNum = 20;BA.debugLine="For i = 0 To length - 1";
{
final int step3 = 1;
final int limit3 = (int) (_length-1);
_i = (int) (0) ;
for (;_i <= limit3 ;_i = _i + step3 ) {
 //BA.debugLineNum = 21;BA.debugLine="RandomStr = RandomStr & (abc.CharAt(Rnd(0,abc.Le";
_randomstr = _randomstr+BA.ObjectToString((_abc.charAt(anywheresoftware.b4a.keywords.Common.Rnd((int) (0),_abc.length()))));
 }
};
 //BA.debugLineNum = 23;BA.debugLine="Return RandomStr";
if (true) return _randomstr;
 //BA.debugLineNum = 24;BA.debugLine="End Sub";
return "";
}
public static String  _sizecontrols(anywheresoftware.b4j.objects.Form _t,double _width1,double _height1,double _width2,double _height2) throws Exception{
String _praxi1 = "";
String _praxi2 = "";
double _mp1 = 0;
double _mp2 = 0;
int _a = 0;
anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper _n = null;
 //BA.debugLineNum = 40;BA.debugLine="Sub SizeControls(t As Form, width1 As Double, heig";
 //BA.debugLineNum = 41;BA.debugLine="alltextcount=0";
_alltextcount = (int) (0);
 //BA.debugLineNum = 42;BA.debugLine="Dim praxi1 As String, praxi2 As String";
_praxi1 = "";
_praxi2 = "";
 //BA.debugLineNum = 43;BA.debugLine="Dim mp1 As Double, mp2 As Double";
_mp1 = 0;
_mp2 = 0;
 //BA.debugLineNum = 45;BA.debugLine="If width2 > width1 Then praxi1=\"*\" Else praxi1=\":";
if (_width2>_width1) { 
_praxi1 = "*";}
else {
_praxi1 = ":";};
 //BA.debugLineNum = 46;BA.debugLine="If height2 > height1 Then praxi2=\"*\" Else praxi2=";
if (_height2>_height1) { 
_praxi2 = "*";}
else {
_praxi2 = ":";};
 //BA.debugLineNum = 47;BA.debugLine="If praxi1=\"*\" Then";
if ((_praxi1).equals("*")) { 
 //BA.debugLineNum = 48;BA.debugLine="mp1=width2/width1";
_mp1 = _width2/(double)_width1;
 }else {
 //BA.debugLineNum = 50;BA.debugLine="mp1=width1/width2";
_mp1 = _width1/(double)_width2;
 };
 //BA.debugLineNum = 52;BA.debugLine="If praxi2=\"*\" Then";
if ((_praxi2).equals("*")) { 
 //BA.debugLineNum = 53;BA.debugLine="mp2=height2/height1";
_mp2 = _height2/(double)_height1;
 }else {
 //BA.debugLineNum = 55;BA.debugLine="mp2=height1/height2";
_mp2 = _height1/(double)_height2;
 };
 //BA.debugLineNum = 58;BA.debugLine="For a = 0 To t.RootPane.NumberOfNodes -1";
{
final int step16 = 1;
final int limit16 = (int) (_t.getRootPane().getNumberOfNodes()-1);
_a = (int) (0) ;
for (;_a <= limit16 ;_a = _a + step16 ) {
 //BA.debugLineNum = 59;BA.debugLine="Dim N As Node = t.RootPane.GetNode(a)";
_n = new anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper();
_n = _t.getRootPane().GetNode(_a);
 //BA.debugLineNum = 61;BA.debugLine="SizeNode(N,praxi1,praxi2,mp1,mp2)";
_sizenode(_n,_praxi1,_praxi2,_mp1,_mp2);
 }
};
 //BA.debugLineNum = 64;BA.debugLine="End Sub";
return "";
}
public static String  _sizenode(anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper _n,String _praxi1,String _praxi2,double _mp1,double _mp2) throws Exception{
double _ss = 0;
int _a = 0;
anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper _nn = null;
anywheresoftware.b4a.objects.B4XViewWrapper _n1 = null;
 //BA.debugLineNum = 67;BA.debugLine="Private Sub SizeNode(N As Node, praxi1 As String,";
 //BA.debugLineNum = 69;BA.debugLine="Dim SS As Double";
_ss = 0;
 //BA.debugLineNum = 71;BA.debugLine="If praxi1=\"*\" Then n.Left=n.left * mp1 Else n.Lef";
if ((_praxi1).equals("*")) { 
_n.setLeft(_n.getLeft()*_mp1);}
else {
_n.setLeft(_n.getLeft()/(double)_mp1);};
 //BA.debugLineNum = 72;BA.debugLine="If praxi2=\"*\" Then n.Top=n.Top*mp2 Else n.Top=n.T";
if ((_praxi2).equals("*")) { 
_n.setTop(_n.getTop()*_mp2);}
else {
_n.setTop(_n.getTop()/(double)_mp2);};
 //BA.debugLineNum = 73;BA.debugLine="If praxi1=\"*\" Then n.PrefWidth=n.PrefWidth*mp1 El";
if ((_praxi1).equals("*")) { 
_n.setPrefWidth(_n.getPrefWidth()*_mp1);}
else {
_n.setPrefWidth(_n.getPrefWidth()/(double)_mp1);};
 //BA.debugLineNum = 74;BA.debugLine="If praxi2=\"*\" Then n.PrefHeight=n.PrefHeight*mp2";
if ((_praxi2).equals("*")) { 
_n.setPrefHeight(_n.getPrefHeight()*_mp2);}
else {
_n.setPrefHeight(_n.getPrefHeight()/(double)_mp2);};
 //BA.debugLineNum = 77;BA.debugLine="If n Is Pane  And n.Tag = \"\" Then";
if (_n.getObjectOrNull() instanceof javafx.scene.layout.Pane && (_n.getTag()).equals((Object)(""))) { 
 //BA.debugLineNum = 78;BA.debugLine="For a = 0 To N.As(Pane).NumberOfNodes -1";
{
final int step7 = 1;
final int limit7 = (int) (((anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper(), (javafx.scene.layout.Pane)(_n.getObject()))).getNumberOfNodes()-1);
_a = (int) (0) ;
for (;_a <= limit7 ;_a = _a + step7 ) {
 //BA.debugLineNum = 79;BA.debugLine="Dim NN As Node = N.As(Pane).GetNode(a)";
_nn = new anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper();
_nn = ((anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper(), (javafx.scene.layout.Pane)(_n.getObject()))).GetNode(_a);
 //BA.debugLineNum = 80;BA.debugLine="SizeNode(NN,praxi1,praxi2,mp1,mp2)";
_sizenode(_nn,_praxi1,_praxi2,_mp1,_mp2);
 //BA.debugLineNum = 81;BA.debugLine="SS=NN.As(B4XView).TextSize";
_ss = ((anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_nn.getObject()))).getTextSize();
 //BA.debugLineNum = 82;BA.debugLine="If SS>0 Then";
if (_ss>0) { 
 //BA.debugLineNum = 83;BA.debugLine="alltextcount=alltextcount+1";
_alltextcount = (int) (_alltextcount+1);
 //BA.debugLineNum = 84;BA.debugLine="If alltextsizes(alltextcount)=0 Then alltextsi";
if (_alltextsizes[_alltextcount]==0) { 
_alltextsizes[_alltextcount] = (int) (_ss);};
 //BA.debugLineNum = 86;BA.debugLine="If praxi2=\"*\" Then";
if ((_praxi2).equals("*")) { 
 //BA.debugLineNum = 87;BA.debugLine="SS=alltextsizes(alltextcount) + (multiplyform";
_ss = _alltextsizes[_alltextcount]+(_multiplyform/(double)30);
 //BA.debugLineNum = 88;BA.debugLine="If SS<7 Then SS=7";
if (_ss<7) { 
_ss = 7;};
 //BA.debugLineNum = 89;BA.debugLine="If SS>32 Then SS=32";
if (_ss>32) { 
_ss = 32;};
 //BA.debugLineNum = 90;BA.debugLine="NN.As(B4XView).TextSize=SS";
((anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_nn.getObject()))).setTextSize(_ss);
 }else {
 //BA.debugLineNum = 92;BA.debugLine="SS=alltextsizes(alltextcount) + (multiplyform";
_ss = _alltextsizes[_alltextcount]+(_multiplyform/(double)30);
 //BA.debugLineNum = 93;BA.debugLine="If SS<7 Then SS=7";
if (_ss<7) { 
_ss = 7;};
 //BA.debugLineNum = 94;BA.debugLine="If SS>32 Then SS=32";
if (_ss>32) { 
_ss = 32;};
 //BA.debugLineNum = 95;BA.debugLine="NN.As(B4XView).TextSize=SS";
((anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_nn.getObject()))).setTextSize(_ss);
 };
 };
 //BA.debugLineNum = 99;BA.debugLine="NN.As(B4XView).TextSize=SS";
((anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_nn.getObject()))).setTextSize(_ss);
 }
};
 }else {
 //BA.debugLineNum = 102;BA.debugLine="If N Is Pane Then";
if (_n.getObjectOrNull() instanceof javafx.scene.layout.Pane) { 
 //BA.debugLineNum = 103;BA.debugLine="For Each N1 As B4XView In N.As(B4XView).GetAllV";
_n1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
{
final anywheresoftware.b4a.BA.IterableList group30 = ((anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_n.getObject()))).GetAllViewsRecursive();
final int groupLen30 = group30.getSize()
;int index30 = 0;
;
for (; index30 < groupLen30;index30++){
_n1 = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(group30.Get(index30)));
 //BA.debugLineNum = 105;BA.debugLine="SS=N1.TextSize";
_ss = _n1.getTextSize();
 //BA.debugLineNum = 106;BA.debugLine="If SS>0 Then";
if (_ss>0) { 
 //BA.debugLineNum = 107;BA.debugLine="alltextcount=alltextcount+1";
_alltextcount = (int) (_alltextcount+1);
 //BA.debugLineNum = 108;BA.debugLine="If alltextsizes(alltextcount)=0 Then alltexts";
if (_alltextsizes[_alltextcount]==0) { 
_alltextsizes[_alltextcount] = (int) (_ss);};
 //BA.debugLineNum = 110;BA.debugLine="If praxi2=\"*\" Then";
if ((_praxi2).equals("*")) { 
 //BA.debugLineNum = 111;BA.debugLine="SS=alltextsizes(alltextcount) + (multiplyfor";
_ss = _alltextsizes[_alltextcount]+(_multiplyform/(double)30);
 //BA.debugLineNum = 112;BA.debugLine="If SS<7 Then SS=7";
if (_ss<7) { 
_ss = 7;};
 //BA.debugLineNum = 113;BA.debugLine="If SS>32 Then SS=32";
if (_ss>32) { 
_ss = 32;};
 //BA.debugLineNum = 114;BA.debugLine="N1.TextSize=SS";
_n1.setTextSize(_ss);
 }else {
 //BA.debugLineNum = 116;BA.debugLine="SS=alltextsizes(alltextcount) + (multiplyfor";
_ss = _alltextsizes[_alltextcount]+(_multiplyform/(double)30);
 //BA.debugLineNum = 117;BA.debugLine="If SS<7 Then SS=7";
if (_ss<7) { 
_ss = 7;};
 //BA.debugLineNum = 118;BA.debugLine="If SS>32 Then SS=32";
if (_ss>32) { 
_ss = 32;};
 //BA.debugLineNum = 119;BA.debugLine="N1.TextSize=SS";
_n1.setTextSize(_ss);
 };
 };
 }
};
 };
 };
 //BA.debugLineNum = 126;BA.debugLine="End Sub";
return "";
}
}
