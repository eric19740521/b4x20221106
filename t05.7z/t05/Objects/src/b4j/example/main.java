package b4j.example;


import anywheresoftware.b4a.BA;

public class main extends javafx.application.Application{
public static main mostCurrent = new main();

public static BA ba;
static {
		ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.main", null);
		ba.loadHtSubs(main.class);
        if (ba.getClass().getName().endsWith("ShellBA")) {
			
			ba.raiseEvent2(null, true, "SHELL", false);
			ba.raiseEvent2(null, true, "CREATE", true, "b4j.example.main", ba);
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}

 
    public static void main(String[] args) {
    	launch(args);
    }
    public void start (javafx.stage.Stage stage) {
        try {
            if (!false)
                System.setProperty("prism.lcdtext", "false");
            anywheresoftware.b4j.objects.FxBA.application = this;
		    anywheresoftware.b4a.keywords.Common.setDensity(javafx.stage.Screen.getPrimary().getDpi());
            anywheresoftware.b4a.keywords.Common.LogDebug("Program started.");
            initializeProcessGlobals();
            anywheresoftware.b4j.objects.Form frm = new anywheresoftware.b4j.objects.Form();
            frm.initWithStage(ba, stage, 600, 600);
            ba.raiseEvent(null, "appstart", frm, (String[])getParameters().getRaw().toArray(new String[0]));
        } catch (Throwable t) {
            BA.printException(t, true);
            System.exit(1);
        }
    }
public static anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4j.objects.JFX _fx = null;
public static anywheresoftware.b4j.objects.Form _mainform = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public static b4j.example.main._point _prevpoint = null;
public static anywheresoftware.b4a.objects.Timer _tmr = null;
public static long _tmrinterval = 0L;
public static int _progress = 0;
public static anywheresoftware.b4j.objects.TabPaneWrapper _tabpane1 = null;
public static anywheresoftware.b4j.objects.TabPaneWrapper.TabWrapper[] _tabpages = null;
public static anywheresoftware.b4j.objects.AccordionWrapper _accordion1 = null;
public static anywheresoftware.b4j.objects.CanvasWrapper _canvas1 = null;
public static anywheresoftware.b4j.objects.ChoiceBoxWrapper _choicebox1 = null;
public static boolean _bchangedfromcode = false;
public static anywheresoftware.b4j.objects.LabelWrapper _label1 = null;
public static anywheresoftware.b4j.objects.LabelWrapper _label2 = null;
public static anywheresoftware.b4j.objects.ButtonWrapper _btnb01 = null;
public static anywheresoftware.b4j.objects.ButtonWrapper _btnb02 = null;
public static anywheresoftware.b4j.objects.ButtonWrapper _btnpane1 = null;
public static anywheresoftware.b4j.objects.ColorPickerWrapper _colorpicker1 = null;
public static anywheresoftware.b4j.objects.DatePickerWrapper _datepicker1 = null;
public static anywheresoftware.b4j.objects.ImageViewWrapper _imageview1 = null;
public static anywheresoftware.b4j.objects.HTMLEditorWrapper _htmleditor1 = null;
public static anywheresoftware.b4j.objects.WebViewWrapper _webview1 = null;
public static anywheresoftware.b4j.objects.MenuItemWrapper.MenuBarWrapper _mb = null;
public static anywheresoftware.b4j.objects.TableViewWrapper _tableview1 = null;
public static anywheresoftware.b4j.objects.PaginationWrapper _pagination1 = null;
public static anywheresoftware.b4j.objects.TextInputControlWrapper.TextFieldWrapper _txte01 = null;
public static anywheresoftware.b4j.objects.TextInputControlWrapper.TextFieldWrapper _txte02 = null;
public static anywheresoftware.b4j.objects.ListViewWrapper _listview1 = null;
public static anywheresoftware.b4j.objects.TextInputControlWrapper.TextFieldWrapper _txtf02 = null;
public static anywheresoftware.b4j.objects.TextInputControlWrapper.TextFieldWrapper _txtf01 = null;
public static anywheresoftware.b4j.objects.ComboBoxWrapper _cbf01 = null;
public static anywheresoftware.b4j.objects.CheckboxWrapper _chkf01 = null;
public static anywheresoftware.b4j.objects.CheckboxWrapper _chkf02 = null;
public static anywheresoftware.b4j.objects.CheckboxWrapper _chkf03 = null;
public static anywheresoftware.b4j.objects.CheckboxWrapper _chkf04 = null;
public static anywheresoftware.b4j.objects.ButtonWrapper.RadioButtonWrapper _rbf01 = null;
public static anywheresoftware.b4j.objects.ButtonWrapper.RadioButtonWrapper _rbf02 = null;
public static anywheresoftware.b4j.objects.ButtonWrapper.RadioButtonWrapper _rbf03 = null;
public static anywheresoftware.b4j.objects.ButtonWrapper.RadioButtonWrapper _rbf04 = null;
public static anywheresoftware.b4j.objects.TextInputControlWrapper.TextFieldWrapper _txtf03 = null;
public static anywheresoftware.b4j.objects.TextInputControlWrapper.TextFieldWrapper _txtf04 = null;
public static anywheresoftware.b4j.objects.ProgressIndicatorWrapper.ProgressBarWrapper _progressbar1 = null;
public static anywheresoftware.b4j.objects.LabelWrapper _label_progress = null;
public static anywheresoftware.b4j.objects.ProgressIndicatorWrapper _progressindicator1 = null;
public static anywheresoftware.b4j.objects.TextInputControlWrapper.TextFieldWrapper _txth01 = null;
public static anywheresoftware.b4j.objects.SliderWrapper _slider1 = null;
public static anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper _paneh01 = null;
public static anywheresoftware.b4j.objects.ScrollPaneWrapper _scrollpane1 = null;
public static int _startleft = 0;
public static int _starttop = 0;
public static int _startx = 0;
public static int _starty = 0;
public static anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper _p_map = null;
public static b4j.example.dateutils _dateutils = null;
public static b4j.example.cssutils _cssutils = null;
public static b4j.example.utils _utils = null;
public static b4j.example.xuiviewsutils _xuiviewsutils = null;
public static class _textmetric{
public boolean IsInitialized;
public double Width;
public double Height;
public void Initialize() {
IsInitialized = true;
Width = 0;
Height = 0;
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public static class _point{
public boolean IsInitialized;
public double x;
public double y;
public void Initialize() {
IsInitialized = true;
x = 0;
y = 0;
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public static String  _accordion1_panechanged(anywheresoftware.b4j.objects.AccordionWrapper.TitledPaneWrapper _expandedpane) throws Exception{
 //BA.debugLineNum = 293;BA.debugLine="Sub Accordion1_PaneChanged (ExpandedPane As Titled";
 //BA.debugLineNum = 294;BA.debugLine="If ExpandedPane.IsInitialized Then";
if (_expandedpane.IsInitialized()) { 
 //BA.debugLineNum = 295;BA.debugLine="Log(\"Current Pane: \" & ExpandedPane.Text)";
anywheresoftware.b4a.keywords.Common.LogImpl("5458754","Current Pane: "+_expandedpane.getText(),0);
 };
 //BA.debugLineNum = 297;BA.debugLine="End Sub";
return "";
}
public static String  _appstart(anywheresoftware.b4j.objects.Form _form1,String[] _args) throws Exception{
anywheresoftware.b4j.objects.TabPaneWrapper.TabWrapper _tp = null;
anywheresoftware.b4j.object.JavaObject _jotp = null;
Object _otp = null;
anywheresoftware.b4a.objects.collections.List _list1 = null;
anywheresoftware.b4j.objects.MenuItemWrapper.MenuWrapper _filem1 = null;
anywheresoftware.b4j.objects.MenuItemWrapper.ConcreteMenuItemWrapper _fileopenm101 = null;
anywheresoftware.b4j.objects.MenuItemWrapper.ConcreteMenuItemWrapper _fileopenm102 = null;
anywheresoftware.b4j.objects.MenuItemWrapper.MenuWrapper _filem2 = null;
anywheresoftware.b4j.objects.MenuItemWrapper.ConcreteMenuItemWrapper _fileopenm201 = null;
anywheresoftware.b4j.object.JavaObject _jo = null;
anywheresoftware.b4j.object.JavaObject _scrollevent = null;
 //BA.debugLineNum = 97;BA.debugLine="Sub AppStart (Form1 As Form, Args() As String)";
 //BA.debugLineNum = 98;BA.debugLine="MainForm = Form1";
_mainform = _form1;
 //BA.debugLineNum = 99;BA.debugLine="MainForm.RootPane.LoadLayout(\"main\")";
_mainform.getRootPane().LoadLayout(ba,"main");
 //BA.debugLineNum = 103;BA.debugLine="TabPane_SetTabClosingPolicy(TabPane1, \"ALL_TABS\")";
_tabpane_settabclosingpolicy(_tabpane1,"ALL_TABS");
 //BA.debugLineNum = 107;BA.debugLine="TabPages(0) = TabPane1.LoadLayout(\"layout01\", \"Ta";
_tabpages[(int) (0)] = _tabpane1.LoadLayout(ba,"layout01","Tab 1");
 //BA.debugLineNum = 108;BA.debugLine="TabPages(0).Id = 0";
_tabpages[(int) (0)].setId(BA.NumberToString(0));
 //BA.debugLineNum = 109;BA.debugLine="TabPages(0).Tag = 1";
_tabpages[(int) (0)].setTag((Object)(1));
 //BA.debugLineNum = 110;BA.debugLine="TabPages(1) = TabPane1.LoadLayout(\"layout02\", \"Ta";
_tabpages[(int) (1)] = _tabpane1.LoadLayout(ba,"layout02","Tab 2");
 //BA.debugLineNum = 111;BA.debugLine="TabPages(1).Id = 1";
_tabpages[(int) (1)].setId(BA.NumberToString(1));
 //BA.debugLineNum = 112;BA.debugLine="TabPages(1).Tag = 1";
_tabpages[(int) (1)].setTag((Object)(1));
 //BA.debugLineNum = 113;BA.debugLine="TabPages(2) = TabPane1.LoadLayout(\"layout03\", \"Ta";
_tabpages[(int) (2)] = _tabpane1.LoadLayout(ba,"layout03","Tab 3");
 //BA.debugLineNum = 114;BA.debugLine="TabPages(2).Id = 2";
_tabpages[(int) (2)].setId(BA.NumberToString(2));
 //BA.debugLineNum = 115;BA.debugLine="TabPages(2).Tag = 1";
_tabpages[(int) (2)].setTag((Object)(1));
 //BA.debugLineNum = 116;BA.debugLine="TabPages(3) = TabPane1.LoadLayout(\"layout04\", \"Ta";
_tabpages[(int) (3)] = _tabpane1.LoadLayout(ba,"layout04","Tab 4");
 //BA.debugLineNum = 117;BA.debugLine="TabPages(3).Id = 3";
_tabpages[(int) (3)].setId(BA.NumberToString(3));
 //BA.debugLineNum = 118;BA.debugLine="TabPages(3).Tag = 1";
_tabpages[(int) (3)].setTag((Object)(1));
 //BA.debugLineNum = 119;BA.debugLine="TabPages(4) = TabPane1.LoadLayout(\"layout05\", \"Ta";
_tabpages[(int) (4)] = _tabpane1.LoadLayout(ba,"layout05","Tab 5");
 //BA.debugLineNum = 120;BA.debugLine="TabPages(4).Id = 4";
_tabpages[(int) (4)].setId(BA.NumberToString(4));
 //BA.debugLineNum = 121;BA.debugLine="TabPages(4).Tag = 1";
_tabpages[(int) (4)].setTag((Object)(1));
 //BA.debugLineNum = 122;BA.debugLine="TabPages(5) = TabPane1.LoadLayout(\"layout06\", \"Ta";
_tabpages[(int) (5)] = _tabpane1.LoadLayout(ba,"layout06","Tab 6");
 //BA.debugLineNum = 123;BA.debugLine="TabPages(5).Id = 5";
_tabpages[(int) (5)].setId(BA.NumberToString(5));
 //BA.debugLineNum = 124;BA.debugLine="TabPages(5).Tag = 1";
_tabpages[(int) (5)].setTag((Object)(1));
 //BA.debugLineNum = 125;BA.debugLine="TabPages(6) = TabPane1.LoadLayout(\"layout07\", \"Ta";
_tabpages[(int) (6)] = _tabpane1.LoadLayout(ba,"layout07","Tab 7");
 //BA.debugLineNum = 126;BA.debugLine="TabPages(6).Id = 6";
_tabpages[(int) (6)].setId(BA.NumberToString(6));
 //BA.debugLineNum = 127;BA.debugLine="TabPages(6).Tag = 1";
_tabpages[(int) (6)].setTag((Object)(1));
 //BA.debugLineNum = 128;BA.debugLine="TabPages(7) = TabPane1.LoadLayout(\"layout08\", \"Ta";
_tabpages[(int) (7)] = _tabpane1.LoadLayout(ba,"layout08","Tab 8");
 //BA.debugLineNum = 129;BA.debugLine="TabPages(7).Id = 7";
_tabpages[(int) (7)].setId(BA.NumberToString(7));
 //BA.debugLineNum = 130;BA.debugLine="TabPages(7).Tag = 1";
_tabpages[(int) (7)].setTag((Object)(1));
 //BA.debugLineNum = 131;BA.debugLine="TabPages(8) = TabPane1.LoadLayout(\"layout09\", \"Ta";
_tabpages[(int) (8)] = _tabpane1.LoadLayout(ba,"layout09","Tab 9");
 //BA.debugLineNum = 132;BA.debugLine="TabPages(8).Id = 7";
_tabpages[(int) (8)].setId(BA.NumberToString(7));
 //BA.debugLineNum = 133;BA.debugLine="TabPages(8).Tag = 1";
_tabpages[(int) (8)].setTag((Object)(1));
 //BA.debugLineNum = 138;BA.debugLine="For Each tp As TabPage In TabPane1.Tabs";
_tp = new anywheresoftware.b4j.objects.TabPaneWrapper.TabWrapper();
{
final anywheresoftware.b4a.BA.IterableList group31 = _tabpane1.getTabs();
final int groupLen31 = group31.getSize()
;int index31 = 0;
;
for (; index31 < groupLen31;index31++){
_tp = (anywheresoftware.b4j.objects.TabPaneWrapper.TabWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.TabPaneWrapper.TabWrapper(), (javafx.scene.control.Tab)(group31.Get(index31)));
 //BA.debugLineNum = 139;BA.debugLine="Dim joTP As JavaObject = tp";
_jotp = new anywheresoftware.b4j.object.JavaObject();
_jotp = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_tp.getObject()));
 //BA.debugLineNum = 140;BA.debugLine="Dim oTP As Object = joTP.CreateEvent(\"javafx.eve";
_otp = _jotp.CreateEvent(ba,"javafx.event.EventHandler","TabPane_Tools_Close",(Object)(anywheresoftware.b4a.keywords.Common.False));
 //BA.debugLineNum = 141;BA.debugLine="joTP.RunMethod(\"setOnClosed\",Array(oTP))";
_jotp.RunMethod("setOnClosed",new Object[]{_otp});
 }
};
 //BA.debugLineNum = 144;BA.debugLine="Accordion1.LoadLayout(\"Pane1\", \"Pane 1\")";
_accordion1.LoadLayout(ba,"Pane1","Pane 1");
 //BA.debugLineNum = 145;BA.debugLine="Accordion1.LoadLayout(\"Pane2\", \"Pane 2\")";
_accordion1.LoadLayout(ba,"Pane2","Pane 2");
 //BA.debugLineNum = 146;BA.debugLine="Accordion1.LoadLayout(\"Pane3\", \"Pane 3\")";
_accordion1.LoadLayout(ba,"Pane3","Pane 3");
 //BA.debugLineNum = 148;BA.debugLine="Private List1 As List";
_list1 = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 149;BA.debugLine="List1.Initialize";
_list1.Initialize();
 //BA.debugLineNum = 151;BA.debugLine="List1.AddAll(Array As String(\"value1\", \"value2\"))";
_list1.AddAll(anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{"value1","value2"}));
 //BA.debugLineNum = 153;BA.debugLine="ChoiceBox1.Items.Add(\"20\")";
_choicebox1.getItems().Add((Object)("20"));
 //BA.debugLineNum = 154;BA.debugLine="ChoiceBox1.Items.Add(\"50\")";
_choicebox1.getItems().Add((Object)("50"));
 //BA.debugLineNum = 155;BA.debugLine="ChoiceBox1.Items.Add(\"100\")";
_choicebox1.getItems().Add((Object)("100"));
 //BA.debugLineNum = 156;BA.debugLine="ChoiceBox1.Items.Add(\"Show all\")";
_choicebox1.getItems().Add((Object)("Show all"));
 //BA.debugLineNum = 158;BA.debugLine="bChangedFromCode = True";
_bchangedfromcode = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 159;BA.debugLine="ChoiceBox1.SelectedIndex = 0 '連動到   	SelectedInde";
_choicebox1.setSelectedIndex((int) (0));
 //BA.debugLineNum = 165;BA.debugLine="MB.Initialize(\"MB\")";
_mb.Initialize(ba,"MB");
 //BA.debugLineNum = 168;BA.debugLine="Private tp As TabPage";
_tp = new anywheresoftware.b4j.objects.TabPaneWrapper.TabWrapper();
 //BA.debugLineNum = 169;BA.debugLine="tp = TabPane1.Tabs.Get(2)";
_tp = (anywheresoftware.b4j.objects.TabPaneWrapper.TabWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.TabPaneWrapper.TabWrapper(), (javafx.scene.control.Tab)(_tabpane1.getTabs().Get((int) (2))));
 //BA.debugLineNum = 170;BA.debugLine="tp.Content.AddNode(MB, 0, 0, 200 , 20)";
_tp.getContent().AddNode((javafx.scene.Node)(_mb.getObject()),0,0,200,20);
 //BA.debugLineNum = 172;BA.debugLine="Dim FileM1 As Menu";
_filem1 = new anywheresoftware.b4j.objects.MenuItemWrapper.MenuWrapper();
 //BA.debugLineNum = 173;BA.debugLine="FileM1.Initialize(\"File\",\"Menu\")";
_filem1.Initialize(ba,"File","Menu");
 //BA.debugLineNum = 175;BA.debugLine="Dim FileOpenM101 As MenuItem";
_fileopenm101 = new anywheresoftware.b4j.objects.MenuItemWrapper.ConcreteMenuItemWrapper();
 //BA.debugLineNum = 176;BA.debugLine="FileOpenM101.Initialize(\"Open\",\"Menu\")";
_fileopenm101.Initialize(ba,"Open","Menu");
 //BA.debugLineNum = 177;BA.debugLine="FileM1.MenuItems.Add(FileOpenM101)";
_filem1.getMenuItems().Add((Object)(_fileopenm101.getObject()));
 //BA.debugLineNum = 178;BA.debugLine="Dim FileOpenM102 As MenuItem";
_fileopenm102 = new anywheresoftware.b4j.objects.MenuItemWrapper.ConcreteMenuItemWrapper();
 //BA.debugLineNum = 179;BA.debugLine="FileOpenM102.Initialize(\"Save\",\"Menu\")";
_fileopenm102.Initialize(ba,"Save","Menu");
 //BA.debugLineNum = 180;BA.debugLine="FileM1.MenuItems.Add(FileOpenM102)";
_filem1.getMenuItems().Add((Object)(_fileopenm102.getObject()));
 //BA.debugLineNum = 183;BA.debugLine="Dim FileM2 As Menu";
_filem2 = new anywheresoftware.b4j.objects.MenuItemWrapper.MenuWrapper();
 //BA.debugLineNum = 184;BA.debugLine="FileM2.Initialize(\"Edit\",\"Menu\")";
_filem2.Initialize(ba,"Edit","Menu");
 //BA.debugLineNum = 186;BA.debugLine="Dim FileOpenM201 As MenuItem";
_fileopenm201 = new anywheresoftware.b4j.objects.MenuItemWrapper.ConcreteMenuItemWrapper();
 //BA.debugLineNum = 187;BA.debugLine="FileOpenM201.Initialize(\"Copy\",\"Menu\")";
_fileopenm201.Initialize(ba,"Copy","Menu");
 //BA.debugLineNum = 188;BA.debugLine="FileM2.MenuItems.Add(FileOpenM201)";
_filem2.getMenuItems().Add((Object)(_fileopenm201.getObject()));
 //BA.debugLineNum = 191;BA.debugLine="MB.Menus.Add(FileM1)";
_mb.getMenus().Add((Object)(_filem1.getObject()));
 //BA.debugLineNum = 192;BA.debugLine="MB.Menus.Add(FileM2)";
_mb.getMenus().Add((Object)(_filem2.getObject()));
 //BA.debugLineNum = 195;BA.debugLine="Dim jo As JavaObject = P_map";
_jo = new anywheresoftware.b4j.object.JavaObject();
_jo = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_p_map.getObject()));
 //BA.debugLineNum = 196;BA.debugLine="Dim ScrollEvent As JavaObject = jo.CreateEventFro";
_scrollevent = new anywheresoftware.b4j.object.JavaObject();
_scrollevent = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_jo.CreateEventFromUI(ba,"javafx.event.EventHandler","ScrollChanged",anywheresoftware.b4a.keywords.Common.Null)));
 //BA.debugLineNum = 197;BA.debugLine="jo.RunMethod(\"setOnScroll\", Array(ScrollEvent))";
_jo.RunMethod("setOnScroll",new Object[]{(Object)(_scrollevent.getObject())});
 //BA.debugLineNum = 201;BA.debugLine="TableView1.SetColumns(Array As String(\"商品編號\", \"商品";
_tableview1.SetColumns(anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{"商品編號","商品名稱","單位","口味","糖份","單價","小計"}));
 //BA.debugLineNum = 202;BA.debugLine="TableView1.SetColumnWidth(0,70)";
_tableview1.SetColumnWidth((int) (0),70);
 //BA.debugLineNum = 203;BA.debugLine="TableView1.SetColumnWidth(1,150)";
_tableview1.SetColumnWidth((int) (1),150);
 //BA.debugLineNum = 204;BA.debugLine="TableView1.SetColumnWidth(2,40)";
_tableview1.SetColumnWidth((int) (2),40);
 //BA.debugLineNum = 205;BA.debugLine="TableView1.SetColumnWidth(3,150)";
_tableview1.SetColumnWidth((int) (3),150);
 //BA.debugLineNum = 206;BA.debugLine="TableView1.SetColumnWidth(4,80)";
_tableview1.SetColumnWidth((int) (4),80);
 //BA.debugLineNum = 207;BA.debugLine="TableView1.SetColumnWidth(5,50)";
_tableview1.SetColumnWidth((int) (5),50);
 //BA.debugLineNum = 208;BA.debugLine="TableView1.SetColumnWidth(6,50)";
_tableview1.SetColumnWidth((int) (6),50);
 //BA.debugLineNum = 211;BA.debugLine="cbF01.Items.Add(\"個\")";
_cbf01.getItems().Add((Object)("個"));
 //BA.debugLineNum = 212;BA.debugLine="cbF01.Items.Add(\"包\")";
_cbf01.getItems().Add((Object)("包"));
 //BA.debugLineNum = 213;BA.debugLine="cbF01.Items.Addall(Array As String(\"盒\",\"罐\"))";
_cbf01.getItems().AddAll(anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{"盒","罐"}));
 //BA.debugLineNum = 214;BA.debugLine="cbF01.SelectedIndex = 0		'第一個";
_cbf01.setSelectedIndex((int) (0));
 //BA.debugLineNum = 217;BA.debugLine="txtF01.Text = Utils.RandomString(4)";
_txtf01.setText(_utils._randomstring /*String*/ ((int) (4)));
 //BA.debugLineNum = 218;BA.debugLine="txtF02.Text = Utils.RandomString(4)";
_txtf02.setText(_utils._randomstring /*String*/ ((int) (4)));
 //BA.debugLineNum = 228;BA.debugLine="Pagination1.LoadLayout(\"PaneG1\")";
_pagination1.LoadLayout(ba,"PaneG1");
 //BA.debugLineNum = 229;BA.debugLine="Pagination1.LoadLayout(\"PaneG2\")";
_pagination1.LoadLayout(ba,"PaneG2");
 //BA.debugLineNum = 230;BA.debugLine="Pagination1.LoadLayout(\"PaneG3\")";
_pagination1.LoadLayout(ba,"PaneG3");
 //BA.debugLineNum = 233;BA.debugLine="tmr.Initialize(\"tmr\", tmrinterval)";
_tmr.Initialize(ba,"tmr",_tmrinterval);
 //BA.debugLineNum = 234;BA.debugLine="tmr.Enabled = False";
_tmr.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 236;BA.debugLine="DatePicker1.DateFormat = \"yyyy/MM/dd\"";
_datepicker1.setDateFormat("yyyy/MM/dd");
 //BA.debugLineNum = 239;BA.debugLine="Log(\"tab9\")";
anywheresoftware.b4a.keywords.Common.LogImpl("565678","tab9",0);
 //BA.debugLineNum = 240;BA.debugLine="ScrollPane1.LoadLayout(\"Form2\", -1, -1)";
_scrollpane1.LoadLayout(ba,"Form2",-1,-1);
 //BA.debugLineNum = 242;BA.debugLine="Log(\"show\")";
anywheresoftware.b4a.keywords.Common.LogImpl("565681","show",0);
 //BA.debugLineNum = 244;BA.debugLine="MainForm.Show";
_mainform.Show();
 //BA.debugLineNum = 245;BA.debugLine="MainForm.AlwaysOnTop = True";
_mainform.setAlwaysOnTop(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 246;BA.debugLine="MainForm.WindowLeft = 0";
_mainform.setWindowLeft(0);
 //BA.debugLineNum = 250;BA.debugLine="End Sub";
return "";
}
public static String  _btnb01_click() throws Exception{
anywheresoftware.b4j.objects.JFX.FontWrapper _fnt = null;
anywheresoftware.b4j.objects.ImageViewWrapper.ImageWrapper _snap = null;
anywheresoftware.b4a.objects.streams.File.OutputStreamWrapper _out = null;
 //BA.debugLineNum = 325;BA.debugLine="Private Sub btnB01_Click";
 //BA.debugLineNum = 327;BA.debugLine="Dim fnt As Font = xui.CreateDefaultFont(20)";
_fnt = new anywheresoftware.b4j.objects.JFX.FontWrapper();
_fnt = (anywheresoftware.b4j.objects.JFX.FontWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.JFX.FontWrapper(), (javafx.scene.text.Font)(_xui.CreateDefaultFont((float) (20)).getObject()));
 //BA.debugLineNum = 328;BA.debugLine="Canvas1.DrawText(\"B4X出品\",20dip,90dip,fnt,fx.Color";
_canvas1.DrawText("B4X出品",anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (20)),anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (90)),(javafx.scene.text.Font)(_fnt.getObject()),_fx.Colors.Blue,BA.getEnumFromString(javafx.scene.text.TextAlignment.class,"LEFT"));
 //BA.debugLineNum = 330;BA.debugLine="Dim snap As Image = Canvas1.Snapshot ' Get Canvas";
_snap = new anywheresoftware.b4j.objects.ImageViewWrapper.ImageWrapper();
_snap = _canvas1.Snapshot();
 //BA.debugLineNum = 331;BA.debugLine="Dim out As OutputStream = File.OpenOutput(File.di";
_out = new anywheresoftware.b4a.objects.streams.File.OutputStreamWrapper();
_out = anywheresoftware.b4a.keywords.Common.File.OpenOutput(anywheresoftware.b4a.keywords.Common.File.getDirApp(),"Canvas.png",anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 332;BA.debugLine="snap.WriteToStream(out)";
_snap.WriteToStream((java.io.OutputStream)(_out.getObject()));
 //BA.debugLineNum = 333;BA.debugLine="out.Close";
_out.Close();
 //BA.debugLineNum = 335;BA.debugLine="xui.MsgboxAsync(\"存檔OK!!\",\"B4X\")";
_xui.MsgboxAsync(ba,"存檔OK!!","B4X");
 //BA.debugLineNum = 336;BA.debugLine="End Sub";
return "";
}
public static String  _btnb02_click() throws Exception{
 //BA.debugLineNum = 320;BA.debugLine="Private Sub btnB02_Click";
 //BA.debugLineNum = 322;BA.debugLine="Canvas1.DrawRect(0, 0, Canvas1.Width, Canvas1.Hei";
_canvas1.DrawRect(0,0,_canvas1.getWidth(),_canvas1.getHeight(),_fx.Colors.White,anywheresoftware.b4a.keywords.Common.True,0);
 //BA.debugLineNum = 323;BA.debugLine="End Sub";
return "";
}
public static String  _btnc01_click() throws Exception{
anywheresoftware.b4j.objects.ImageViewWrapper.ImageWrapper _img = null;
anywheresoftware.b4j.objects.ImageViewWrapper.ImageWrapper _bmp = null;
 //BA.debugLineNum = 450;BA.debugLine="Private Sub btnC01_Click";
 //BA.debugLineNum = 451;BA.debugLine="Log(\"btnC01_Click==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("51310721","btnC01_Click==>",0);
 //BA.debugLineNum = 452;BA.debugLine="Dim img As Image";
_img = new anywheresoftware.b4j.objects.ImageViewWrapper.ImageWrapper();
 //BA.debugLineNum = 454;BA.debugLine="If File.Exists(File.DirApp,\"Canvas.png\") = False";
if (anywheresoftware.b4a.keywords.Common.File.Exists(anywheresoftware.b4a.keywords.Common.File.getDirApp(),"Canvas.png")==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 455;BA.debugLine="xui.MsgboxAsync(\"檔案不存在??\",\"B4X\")";
_xui.MsgboxAsync(ba,"檔案不存在??","B4X");
 //BA.debugLineNum = 456;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 458;BA.debugLine="img.Initialize(File.DirApp,\"Canvas.png\")";
_img.Initialize(anywheresoftware.b4a.keywords.Common.File.getDirApp(),"Canvas.png");
 //BA.debugLineNum = 459;BA.debugLine="Dim bmp As Image = fx.LoadImage(File.DirApp,\"Canv";
_bmp = new anywheresoftware.b4j.objects.ImageViewWrapper.ImageWrapper();
_bmp = _fx.LoadImage(anywheresoftware.b4a.keywords.Common.File.getDirApp(),"Canvas.png");
 //BA.debugLineNum = 462;BA.debugLine="ImageView1.SetImage(img)";
_imageview1.SetImage((javafx.scene.image.Image)(_img.getObject()));
 //BA.debugLineNum = 464;BA.debugLine="ImageView1.SetSize(bmp.Width, bmp.Height)";
_imageview1.SetSize(_bmp.getWidth(),_bmp.getHeight());
 //BA.debugLineNum = 465;BA.debugLine="ImageView1.Left = 0";
_imageview1.setLeft(0);
 //BA.debugLineNum = 466;BA.debugLine="ImageView1.Top = 0";
_imageview1.setTop(0);
 //BA.debugLineNum = 467;BA.debugLine="End Sub";
return "";
}
public static String  _btnd01_click() throws Exception{
 //BA.debugLineNum = 508;BA.debugLine="Private Sub btnD01_Click";
 //BA.debugLineNum = 511;BA.debugLine="WebView1.LoadHtml(HTMLEditor1.HtmlText)";
_webview1.LoadHtml(_htmleditor1.getHtmlText());
 //BA.debugLineNum = 513;BA.debugLine="End Sub";
return "";
}
public static String  _btne01_click() throws Exception{
 //BA.debugLineNum = 519;BA.debugLine="Private Sub btnE01_Click";
 //BA.debugLineNum = 529;BA.debugLine="ListView1.Items.add(\"A001\")";
_listview1.getItems().Add((Object)("A001"));
 //BA.debugLineNum = 530;BA.debugLine="ListView1.Items.add(\"A002\")";
_listview1.getItems().Add((Object)("A002"));
 //BA.debugLineNum = 531;BA.debugLine="ListView1.Items.addall(Array As String(\"A003\",\"A0";
_listview1.getItems().AddAll(anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{"A003","A004"}));
 //BA.debugLineNum = 534;BA.debugLine="End Sub";
return "";
}
public static String  _btnf01_click() throws Exception{
Object[] _row = null;
anywheresoftware.b4j.objects.CheckboxWrapper[] _ch = null;
String _chkstring = "";
int _i = 0;
anywheresoftware.b4j.objects.CheckboxWrapper _c = null;
anywheresoftware.b4j.objects.ButtonWrapper.RadioButtonWrapper[] _rr = null;
String _selectstring = "";
anywheresoftware.b4j.objects.ButtonWrapper.RadioButtonWrapper _r = null;
 //BA.debugLineNum = 597;BA.debugLine="Private Sub btnF01_Click";
 //BA.debugLineNum = 599;BA.debugLine="Dim Row(7) As Object '= Array (\"a\", \"b\", \"c\")";
_row = new Object[(int) (7)];
{
int d0 = _row.length;
for (int i0 = 0;i0 < d0;i0++) {
_row[i0] = new Object();
}
}
;
 //BA.debugLineNum = 601;BA.debugLine="Row(0) = txtF01.Text";
_row[(int) (0)] = (Object)(_txtf01.getText());
 //BA.debugLineNum = 602;BA.debugLine="Row(1) = txtF02.Text";
_row[(int) (1)] = (Object)(_txtf02.getText());
 //BA.debugLineNum = 603;BA.debugLine="Row(2) = cbF01.Value";
_row[(int) (2)] = _cbf01.getValue();
 //BA.debugLineNum = 606;BA.debugLine="Try";
try { //BA.debugLineNum = 607;BA.debugLine="Dim ch(3) As CheckBox = Array As CheckBox(chkF01";
_ch = new anywheresoftware.b4j.objects.CheckboxWrapper[]{_chkf01,_chkf02,_chkf03,_chkf04};
 //BA.debugLineNum = 609;BA.debugLine="Dim chkString As String = \"\"";
_chkstring = "";
 //BA.debugLineNum = 610;BA.debugLine="For i=0 To ch.Length-1";
{
final int step8 = 1;
final int limit8 = (int) (_ch.length-1);
_i = (int) (0) ;
for (;_i <= limit8 ;_i = _i + step8 ) {
 //BA.debugLineNum = 611;BA.debugLine="Dim c As CheckBox = ch(i)";
_c = new anywheresoftware.b4j.objects.CheckboxWrapper();
_c = _ch[_i];
 //BA.debugLineNum = 612;BA.debugLine="If c.Checked Then";
if (_c.getChecked()) { 
 //BA.debugLineNum = 613;BA.debugLine="chkString = chkString & \",\" & c.Text";
_chkstring = _chkstring+","+_c.getText();
 };
 }
};
 //BA.debugLineNum = 617;BA.debugLine="If chkString.Length > 0 Then";
if (_chkstring.length()>0) { 
 //BA.debugLineNum = 618;BA.debugLine="chkString = chkString.SubString(1)";
_chkstring = _chkstring.substring((int) (1));
 };
 //BA.debugLineNum = 622;BA.debugLine="Row(3) = chkString";
_row[(int) (3)] = (Object)(_chkstring);
 } 
       catch (Exception e19) {
			ba.setLastException(e19); //BA.debugLineNum = 624;BA.debugLine="Log(LastException)";
anywheresoftware.b4a.keywords.Common.LogImpl("51900571",BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(ba)),0);
 };
 //BA.debugLineNum = 630;BA.debugLine="Try";
try { //BA.debugLineNum = 631;BA.debugLine="Dim rr(3) As RadioButton = Array As RadioButton(";
_rr = new anywheresoftware.b4j.objects.ButtonWrapper.RadioButtonWrapper[]{_rbf01,_rbf02,_rbf03,_rbf04};
 //BA.debugLineNum = 633;BA.debugLine="Dim selectString As String = \"\"";
_selectstring = "";
 //BA.debugLineNum = 634;BA.debugLine="For i=0 To rr.Length-1";
{
final int step24 = 1;
final int limit24 = (int) (_rr.length-1);
_i = (int) (0) ;
for (;_i <= limit24 ;_i = _i + step24 ) {
 //BA.debugLineNum = 635;BA.debugLine="Dim r As RadioButton = rr(i)";
_r = new anywheresoftware.b4j.objects.ButtonWrapper.RadioButtonWrapper();
_r = _rr[_i];
 //BA.debugLineNum = 637;BA.debugLine="If r.Selected Then";
if (_r.getSelected()) { 
 //BA.debugLineNum = 638;BA.debugLine="selectString = r.Text";
_selectstring = _r.getText();
 };
 }
};
 } 
       catch (Exception e31) {
			ba.setLastException(e31); //BA.debugLineNum = 643;BA.debugLine="Log(LastException)";
anywheresoftware.b4a.keywords.Common.LogImpl("51900590",BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(ba)),0);
 };
 //BA.debugLineNum = 647;BA.debugLine="Row(4) = selectString";
_row[(int) (4)] = (Object)(_selectstring);
 //BA.debugLineNum = 648;BA.debugLine="Row(5) = txtF03.Text";
_row[(int) (5)] = (Object)(_txtf03.getText());
 //BA.debugLineNum = 649;BA.debugLine="Row(6) = txtF04.Text";
_row[(int) (6)] = (Object)(_txtf04.getText());
 //BA.debugLineNum = 651;BA.debugLine="TableView1.Items.Add(Row)";
_tableview1.getItems().Add((Object)(_row));
 //BA.debugLineNum = 653;BA.debugLine="txtF01.Text = Utils.RandomString(4)";
_txtf01.setText(_utils._randomstring /*String*/ ((int) (4)));
 //BA.debugLineNum = 654;BA.debugLine="txtF02.Text = Utils.RandomString(4)";
_txtf02.setText(_utils._randomstring /*String*/ ((int) (4)));
 //BA.debugLineNum = 658;BA.debugLine="End Sub";
return "";
}
public static String  _btnh01_click() throws Exception{
 //BA.debugLineNum = 763;BA.debugLine="Private Sub btnH01_Click";
 //BA.debugLineNum = 765;BA.debugLine="Progress = 0";
_progress = (int) (0);
 //BA.debugLineNum = 766;BA.debugLine="tmr.Enabled = True";
_tmr.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 769;BA.debugLine="End Sub";
return "";
}
public static String  _btnpane1_action() throws Exception{
 //BA.debugLineNum = 300;BA.debugLine="Sub btnPane1_Action";
 //BA.debugLineNum = 301;BA.debugLine="Accordion1.SelectedIndex = 1";
_accordion1.setSelectedIndex((int) (1));
 //BA.debugLineNum = 302;BA.debugLine="End Sub";
return "";
}
public static String  _btnpane2_action() throws Exception{
 //BA.debugLineNum = 304;BA.debugLine="Sub btnPane2_Action";
 //BA.debugLineNum = 305;BA.debugLine="Accordion1.SelectedIndex = 2";
_accordion1.setSelectedIndex((int) (2));
 //BA.debugLineNum = 306;BA.debugLine="End Sub";
return "";
}
public static String  _btnpane3_action() throws Exception{
 //BA.debugLineNum = 308;BA.debugLine="Sub btnPane3_Action";
 //BA.debugLineNum = 309;BA.debugLine="Accordion1.SelectedIndex = -1";
_accordion1.setSelectedIndex((int) (-1));
 //BA.debugLineNum = 310;BA.debugLine="End Sub";
return "";
}
public static String  _btnpaneg1_click() throws Exception{
 //BA.debugLineNum = 683;BA.debugLine="Private Sub btnPaneG1_Click";
 //BA.debugLineNum = 684;BA.debugLine="Pagination1.SelectedIndex = 1";
_pagination1.setSelectedIndex((int) (1));
 //BA.debugLineNum = 685;BA.debugLine="End Sub";
return "";
}
public static String  _btnpaneg2_click() throws Exception{
 //BA.debugLineNum = 687;BA.debugLine="Private Sub btnPaneG2_Click";
 //BA.debugLineNum = 688;BA.debugLine="Pagination1.SelectedIndex = 2";
_pagination1.setSelectedIndex((int) (2));
 //BA.debugLineNum = 689;BA.debugLine="End Sub";
return "";
}
public static String  _btnpaneg3_click() throws Exception{
 //BA.debugLineNum = 691;BA.debugLine="Private Sub btnPaneG3_Click";
 //BA.debugLineNum = 692;BA.debugLine="Pagination1.SelectedIndex = 0";
_pagination1.setSelectedIndex((int) (0));
 //BA.debugLineNum = 693;BA.debugLine="End Sub";
return "";
}
public static String  _canvas1_mousedragged(anywheresoftware.b4j.objects.NodeWrapper.MouseEventWrapper _eventdata) throws Exception{
b4j.example.main._point _newpoint = null;
 //BA.debugLineNum = 345;BA.debugLine="Sub Canvas1_MouseDragged (EventData As MouseEvent)";
 //BA.debugLineNum = 346;BA.debugLine="If EventData.PrimaryButtonDown Then";
if (_eventdata.getPrimaryButtonDown()) { 
 //BA.debugLineNum = 347;BA.debugLine="Dim NewPoint As Point = Utils.CreatePoint(EventD";
_newpoint = _utils._createpoint /*b4j.example.main._point*/ (_eventdata);
 //BA.debugLineNum = 348;BA.debugLine="If PrevPoint <> Null And PrevPoint.IsInitialized";
if (_prevpoint!= null && _prevpoint.IsInitialized /*boolean*/ ) { 
 //BA.debugLineNum = 349;BA.debugLine="Canvas1.DrawLine(PrevPoint.x, PrevPoint.y, NewP";
_canvas1.DrawLine(_prevpoint.x /*double*/ ,_prevpoint.y /*double*/ ,_newpoint.x /*double*/ ,_newpoint.y /*double*/ ,_fx.Colors.Red,anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (5)));
 };
 //BA.debugLineNum = 351;BA.debugLine="PrevPoint = NewPoint";
_prevpoint = _newpoint;
 };
 //BA.debugLineNum = 353;BA.debugLine="End Sub";
return "";
}
public static String  _canvas1_mousereleased(anywheresoftware.b4j.objects.NodeWrapper.MouseEventWrapper _eventdata) throws Exception{
 //BA.debugLineNum = 355;BA.debugLine="Sub Canvas1_MouseReleased (EventData As MouseEvent";
 //BA.debugLineNum = 356;BA.debugLine="PrevPoint = Null";
_prevpoint = (b4j.example.main._point)(anywheresoftware.b4a.keywords.Common.Null);
 //BA.debugLineNum = 357;BA.debugLine="End Sub";
return "";
}
public static String  _chkf_checkedchange(boolean _checked) throws Exception{
anywheresoftware.b4j.objects.CheckboxWrapper _chk = null;
 //BA.debugLineNum = 552;BA.debugLine="Private Sub chkF_CheckedChange(Checked As Boolean)";
 //BA.debugLineNum = 553;BA.debugLine="Dim chk As CheckBox";
_chk = new anywheresoftware.b4j.objects.CheckboxWrapper();
 //BA.debugLineNum = 555;BA.debugLine="chk = Sender";
_chk = (anywheresoftware.b4j.objects.CheckboxWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.CheckboxWrapper(), (javafx.scene.control.CheckBox)(anywheresoftware.b4a.keywords.Common.Sender(ba)));
 //BA.debugLineNum = 558;BA.debugLine="If txtF04.text = \"\" Then";
if ((_txtf04.getText()).equals("")) { 
 //BA.debugLineNum = 559;BA.debugLine="txtF04.text = txtF03.text";
_txtf04.setText(_txtf03.getText());
 };
 //BA.debugLineNum = 562;BA.debugLine="If Checked Then";
if (_checked) { 
 //BA.debugLineNum = 564;BA.debugLine="Select chk.text";
switch (BA.switchObjectToInt(_chk.getText(),"粉圓","QQ","珍珠","愛玉")) {
case 0: {
 //BA.debugLineNum = 566;BA.debugLine="txtF04.Text = txtF04.text +1";
_txtf04.setText(BA.NumberToString((double)(Double.parseDouble(_txtf04.getText()))+1));
 break; }
case 1: {
 //BA.debugLineNum = 568;BA.debugLine="txtF04.Text = txtF04.text +2";
_txtf04.setText(BA.NumberToString((double)(Double.parseDouble(_txtf04.getText()))+2));
 break; }
case 2: {
 //BA.debugLineNum = 570;BA.debugLine="txtF04.Text = txtF04.text +4";
_txtf04.setText(BA.NumberToString((double)(Double.parseDouble(_txtf04.getText()))+4));
 break; }
case 3: {
 //BA.debugLineNum = 572;BA.debugLine="txtF04.Text = txtF04.text +5";
_txtf04.setText(BA.NumberToString((double)(Double.parseDouble(_txtf04.getText()))+5));
 break; }
default: {
 //BA.debugLineNum = 575;BA.debugLine="Log(\"Larger than 4\")";
anywheresoftware.b4a.keywords.Common.LogImpl("51835031","Larger than 4",0);
 break; }
}
;
 };
 //BA.debugLineNum = 578;BA.debugLine="If Checked = False Then";
if (_checked==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 580;BA.debugLine="Select chk.text";
switch (BA.switchObjectToInt(_chk.getText(),"粉圓","QQ","珍珠","愛玉")) {
case 0: {
 //BA.debugLineNum = 582;BA.debugLine="txtF04.Text = txtF04.text -1";
_txtf04.setText(BA.NumberToString((double)(Double.parseDouble(_txtf04.getText()))-1));
 break; }
case 1: {
 //BA.debugLineNum = 584;BA.debugLine="txtF04.Text = txtF04.text -2";
_txtf04.setText(BA.NumberToString((double)(Double.parseDouble(_txtf04.getText()))-2));
 break; }
case 2: {
 //BA.debugLineNum = 586;BA.debugLine="txtF04.Text = txtF04.text -4";
_txtf04.setText(BA.NumberToString((double)(Double.parseDouble(_txtf04.getText()))-4));
 break; }
case 3: {
 //BA.debugLineNum = 588;BA.debugLine="txtF04.Text = txtF04.text -5";
_txtf04.setText(BA.NumberToString((double)(Double.parseDouble(_txtf04.getText()))-5));
 break; }
default: {
 //BA.debugLineNum = 591;BA.debugLine="Log(\"Larger than 4\")";
anywheresoftware.b4a.keywords.Common.LogImpl("51835047","Larger than 4",0);
 break; }
}
;
 };
 //BA.debugLineNum = 595;BA.debugLine="End Sub";
return "";
}
public static String  _choicebox1_mouseclicked(anywheresoftware.b4j.objects.NodeWrapper.MouseEventWrapper _eventdata) throws Exception{
 //BA.debugLineNum = 825;BA.debugLine="Sub choiceBox1_MouseClicked (EventData As MouseEve";
 //BA.debugLineNum = 826;BA.debugLine="Log(\"choiceBox1_MouseClicked==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("52818049","choiceBox1_MouseClicked==>",0);
 //BA.debugLineNum = 827;BA.debugLine="If ChoiceBox1.SelectedIndex <> -1 Then";
if (_choicebox1.getSelectedIndex()!=-1) { 
 //BA.debugLineNum = 828;BA.debugLine="Log(ChoiceBox1.Items.Get(ChoiceBox1.SelectedInde";
anywheresoftware.b4a.keywords.Common.LogImpl("52818051",BA.ObjectToString(_choicebox1.getItems().Get(_choicebox1.getSelectedIndex())),0);
 };
 //BA.debugLineNum = 834;BA.debugLine="End Sub";
return "";
}
public static String  _choicebox1_mousepressed(anywheresoftware.b4j.objects.NodeWrapper.MouseEventWrapper _eventdata) throws Exception{
 //BA.debugLineNum = 360;BA.debugLine="Private Sub ChoiceBox1_MousePressed (EventData As";
 //BA.debugLineNum = 361;BA.debugLine="Log(\"ChoiceBox1_MousePressed==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("5983041","ChoiceBox1_MousePressed==>",0);
 //BA.debugLineNum = 371;BA.debugLine="End Sub";
return "";
}
public static String  _choicebox1_selectedindexchanged(int _index,Object _value) throws Exception{
 //BA.debugLineNum = 813;BA.debugLine="Private Sub ChoiceBox1_SelectedIndexChanged(Index";
 //BA.debugLineNum = 814;BA.debugLine="Log(\"ChoiceBox1_SelectedIndexChanged==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("52752513","ChoiceBox1_SelectedIndexChanged==>",0);
 //BA.debugLineNum = 816;BA.debugLine="If Not(bChangedFromCode) Then";
if (anywheresoftware.b4a.keywords.Common.Not(_bchangedfromcode)) { 
 //BA.debugLineNum = 817;BA.debugLine="Log(\"ChoiceBox1 Index: \"&Index)";
anywheresoftware.b4a.keywords.Common.LogImpl("52752516","ChoiceBox1 Index: "+BA.NumberToString(_index),0);
 //BA.debugLineNum = 818;BA.debugLine="Log(\"ChoiceBox1 value: \"&Value)";
anywheresoftware.b4a.keywords.Common.LogImpl("52752517","ChoiceBox1 value: "+BA.ObjectToString(_value),0);
 //BA.debugLineNum = 820;BA.debugLine="txtH01.Text = Value";
_txth01.setText(BA.ObjectToString(_value));
 };
 //BA.debugLineNum = 822;BA.debugLine="bChangedFromCode= False";
_bchangedfromcode = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 823;BA.debugLine="End Sub";
return "";
}
public static String  _collectmenuitems(anywheresoftware.b4a.objects.collections.Map _menus,anywheresoftware.b4a.objects.collections.List _items) throws Exception{
anywheresoftware.b4j.objects.MenuItemWrapper.ConcreteMenuItemWrapper _mi = null;
anywheresoftware.b4j.objects.MenuItemWrapper.MenuWrapper _mn = null;
 //BA.debugLineNum = 410;BA.debugLine="Private Sub CollectMenuItems(Menus As Map, Items A";
 //BA.debugLineNum = 411;BA.debugLine="For Each mi As MenuItem In Items";
_mi = new anywheresoftware.b4j.objects.MenuItemWrapper.ConcreteMenuItemWrapper();
{
final anywheresoftware.b4a.BA.IterableList group1 = _items;
final int groupLen1 = group1.getSize()
;int index1 = 0;
;
for (; index1 < groupLen1;index1++){
_mi = (anywheresoftware.b4j.objects.MenuItemWrapper.ConcreteMenuItemWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.MenuItemWrapper.ConcreteMenuItemWrapper(), (javafx.scene.control.MenuItem)(group1.Get(index1)));
 //BA.debugLineNum = 412;BA.debugLine="If mi.Tag <> Null And mi.Tag <> \"\" Then Menus.Pu";
if (_mi.getTag()!= null && (_mi.getTag()).equals((Object)("")) == false) { 
_menus.Put(_mi.getTag(),(Object)(_mi.getObject()));};
 //BA.debugLineNum = 413;BA.debugLine="If mi Is Menu Then";
if (_mi.getObjectOrNull() instanceof javafx.scene.control.Menu) { 
 //BA.debugLineNum = 414;BA.debugLine="Dim mn As Menu = mi";
_mn = new anywheresoftware.b4j.objects.MenuItemWrapper.MenuWrapper();
_mn = (anywheresoftware.b4j.objects.MenuItemWrapper.MenuWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.MenuItemWrapper.MenuWrapper(), (javafx.scene.control.Menu)(_mi.getObject()));
 //BA.debugLineNum = 415;BA.debugLine="CollectMenuItems(Menus, mn.MenuItems)";
_collectmenuitems(_menus,_mn.getMenuItems());
 };
 }
};
 //BA.debugLineNum = 418;BA.debugLine="End Sub";
return "";
}
public static String  _colorpicker1_valuechanged(anywheresoftware.b4j.objects.JFX.PaintWrapper _value) throws Exception{
anywheresoftware.b4j.objects.JFX.PaintWrapper _clr = null;
int _color = 0;
anywheresoftware.b4a.objects.B4XViewWrapper _b4x001 = null;
 //BA.debugLineNum = 782;BA.debugLine="Private Sub ColorPicker1_ValueChanged (Value As Pa";
 //BA.debugLineNum = 784;BA.debugLine="Log(\"RGB: \"&Utils.GetColorRGB(Value))";
anywheresoftware.b4a.keywords.Common.LogImpl("52686978","RGB: "+_utils._getcolorrgb /*String*/ (_value),0);
 //BA.debugLineNum = 791;BA.debugLine="Dim clr As Paint = fx.Colors.From32Bit(Bit.Or(0xF";
_clr = new anywheresoftware.b4j.objects.JFX.PaintWrapper();
_clr = (anywheresoftware.b4j.objects.JFX.PaintWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.JFX.PaintWrapper(), (javafx.scene.paint.Paint)(_fx.Colors.From32Bit(anywheresoftware.b4a.keywords.Common.Bit.Or(((int)0xff000000),_fx.Colors.To32Bit((javafx.scene.paint.Paint)(_value.getObject()))))));
 //BA.debugLineNum = 792;BA.debugLine="CSSUtils.SetBackgroundColor(PaneH01, clr)";
_cssutils._setbackgroundcolor((anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper(), (javafx.scene.Node)(_paneh01.getObject())),_clr);
 //BA.debugLineNum = 796;BA.debugLine="Dim color As Int = xui.PaintOrColorToColor(Value)";
_color = _xui.PaintOrColorToColor((Object)(_value.getObject()));
 //BA.debugLineNum = 797;BA.debugLine="Dim b4x001 As B4XView";
_b4x001 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 799;BA.debugLine="b4x001 = txtH01";
_b4x001 = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_txth01.getObject()));
 //BA.debugLineNum = 800;BA.debugLine="b4x001.Color = color";
_b4x001.setColor(_color);
 //BA.debugLineNum = 801;BA.debugLine="End Sub";
return "";
}
public static String  _datepicker1_valuechanged(long _value) throws Exception{
 //BA.debugLineNum = 775;BA.debugLine="Private Sub DatePicker1_ValueChanged (Value As Lon";
 //BA.debugLineNum = 778;BA.debugLine="DateTime.DateFormat = \"yyyy/MM/dd\"";
anywheresoftware.b4a.keywords.Common.DateTime.setDateFormat("yyyy/MM/dd");
 //BA.debugLineNum = 779;BA.debugLine="txtH01.Text = DateTime.Date( DatePicker1.DateTick";
_txth01.setText(anywheresoftware.b4a.keywords.Common.DateTime.Date(_datepicker1.getDateTicks()));
 //BA.debugLineNum = 780;BA.debugLine="End Sub";
return "";
}
public static String  _mainform_resize(double _width,double _height) throws Exception{
 //BA.debugLineNum = 252;BA.debugLine="Sub MainForm_Resize (Width As Double, Height As Do";
 //BA.debugLineNum = 255;BA.debugLine="Utils.SizeControls(MainForm, 600, 600, Width, Hei";
_utils._sizecontrols /*String*/ (_mainform,600,600,_width,_height);
 //BA.debugLineNum = 256;BA.debugLine="End Sub";
return "";
}
public static String  _menu_action() throws Exception{
anywheresoftware.b4j.objects.MenuItemWrapper.ConcreteMenuItemWrapper _mi = null;
anywheresoftware.b4j.objects.ImageViewWrapper.ImageWrapper _img = null;
 //BA.debugLineNum = 375;BA.debugLine="Private Sub Menu_Action";
 //BA.debugLineNum = 376;BA.debugLine="Log(\"Menu_Action==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("51048577","Menu_Action==>",0);
 //BA.debugLineNum = 377;BA.debugLine="Dim MI As MenuItem = Sender";
_mi = new anywheresoftware.b4j.objects.MenuItemWrapper.ConcreteMenuItemWrapper();
_mi = (anywheresoftware.b4j.objects.MenuItemWrapper.ConcreteMenuItemWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.MenuItemWrapper.ConcreteMenuItemWrapper(), (javafx.scene.control.MenuItem)(anywheresoftware.b4a.keywords.Common.Sender(ba)));
 //BA.debugLineNum = 379;BA.debugLine="Log(\"MenuItem Text: \"&MI.Text)";
anywheresoftware.b4a.keywords.Common.LogImpl("51048580","MenuItem Text: "+_mi.getText(),0);
 //BA.debugLineNum = 380;BA.debugLine="Select MI.Text";
switch (BA.switchObjectToInt(_mi.getText(),"Open")) {
case 0: {
 //BA.debugLineNum = 382;BA.debugLine="Log(\"Open Menu Action\")";
anywheresoftware.b4a.keywords.Common.LogImpl("51048583","Open Menu Action",0);
 //BA.debugLineNum = 384;BA.debugLine="Dim img As Image";
_img = new anywheresoftware.b4j.objects.ImageViewWrapper.ImageWrapper();
 //BA.debugLineNum = 386;BA.debugLine="If File.Exists(File.DirApp,\"Canvas.png\") = Fals";
if (anywheresoftware.b4a.keywords.Common.File.Exists(anywheresoftware.b4a.keywords.Common.File.getDirApp(),"Canvas.png")==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 387;BA.debugLine="xui.MsgboxAsync(\"檔案不存在??\",\"B4X\")";
_xui.MsgboxAsync(ba,"檔案不存在??","B4X");
 //BA.debugLineNum = 388;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 390;BA.debugLine="img.Initialize(File.DirApp,\"Canvas.png\")";
_img.Initialize(anywheresoftware.b4a.keywords.Common.File.getDirApp(),"Canvas.png");
 //BA.debugLineNum = 392;BA.debugLine="ImageView1.SetImage(img)";
_imageview1.SetImage((javafx.scene.image.Image)(_img.getObject()));
 break; }
}
;
 //BA.debugLineNum = 398;BA.debugLine="End Sub";
return "";
}
public static anywheresoftware.b4a.objects.collections.Map  _menubar_items(anywheresoftware.b4j.objects.MenuItemWrapper.MenuBarWrapper _mnubar) throws Exception{
anywheresoftware.b4a.objects.collections.Map _menus = null;
 //BA.debugLineNum = 402;BA.debugLine="Public Sub MenuBar_Items(MnuBar As MenuBar) As Map";
 //BA.debugLineNum = 403;BA.debugLine="Dim menus As Map";
_menus = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 404;BA.debugLine="menus.Initialize";
_menus.Initialize();
 //BA.debugLineNum = 405;BA.debugLine="CollectMenuItems(menus, MnuBar.Menus)";
_collectmenuitems(_menus,_mnubar.getMenus());
 //BA.debugLineNum = 406;BA.debugLine="Return menus";
if (true) return _menus;
 //BA.debugLineNum = 407;BA.debugLine="End Sub";
return null;
}
public static String  _menubar_menuitem_setimage(anywheresoftware.b4a.objects.collections.Map _menuitems,String _item,anywheresoftware.b4j.objects.ImageViewWrapper.ImageWrapper _img) throws Exception{
anywheresoftware.b4j.objects.MenuItemWrapper.ConcreteMenuItemWrapper _mi = null;
 //BA.debugLineNum = 421;BA.debugLine="Public Sub MenuBar_MenuItem_SetImage(MenuItems As";
 //BA.debugLineNum = 422;BA.debugLine="Dim mi As MenuItem = MenuItems.Get(Item)";
_mi = new anywheresoftware.b4j.objects.MenuItemWrapper.ConcreteMenuItemWrapper();
_mi = (anywheresoftware.b4j.objects.MenuItemWrapper.ConcreteMenuItemWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.MenuItemWrapper.ConcreteMenuItemWrapper(), (javafx.scene.control.MenuItem)(_menuitems.Get((Object)(_item))));
 //BA.debugLineNum = 423;BA.debugLine="If mi.IsInitialized Then";
if (_mi.IsInitialized()) { 
 //BA.debugLineNum = 424;BA.debugLine="mi.Image = Img";
_mi.setImage((javafx.scene.image.Image)(_img.getObject()));
 };
 //BA.debugLineNum = 426;BA.debugLine="End Sub";
return "";
}
public static String  _p_map_mousedragged(anywheresoftware.b4j.objects.NodeWrapper.MouseEventWrapper _eventdata) throws Exception{
 //BA.debugLineNum = 477;BA.debugLine="Sub P_map_MouseDragged (EventData As MouseEvent)";
 //BA.debugLineNum = 478;BA.debugLine="ImageView1.Left = Min(0.5 * P_map.Width, StartLef";
_imageview1.setLeft(anywheresoftware.b4a.keywords.Common.Min(0.5*_p_map.getWidth(),_startleft+1.2*(_eventdata.getX()-_startx)));
 //BA.debugLineNum = 479;BA.debugLine="ImageView1.Left = Max(-(ImageView1.Width - 0.5 *";
_imageview1.setLeft(anywheresoftware.b4a.keywords.Common.Max(-(_imageview1.getWidth()-0.5*_p_map.getWidth()),_imageview1.getLeft()));
 //BA.debugLineNum = 480;BA.debugLine="ImageView1.Top = Min(0.5 * P_map.Height, StartTop";
_imageview1.setTop(anywheresoftware.b4a.keywords.Common.Min(0.5*_p_map.getHeight(),_starttop+1.2*(_eventdata.getY()-_starty)));
 //BA.debugLineNum = 481;BA.debugLine="ImageView1.Top = Max(-(ImageView1.Height - 0.5 *";
_imageview1.setTop(anywheresoftware.b4a.keywords.Common.Max(-(_imageview1.getHeight()-0.5*_p_map.getHeight()),_imageview1.getTop()));
 //BA.debugLineNum = 482;BA.debugLine="End Sub";
return "";
}
public static String  _p_map_mousepressed(anywheresoftware.b4j.objects.NodeWrapper.MouseEventWrapper _eventdata) throws Exception{
 //BA.debugLineNum = 470;BA.debugLine="Sub P_map_MousePressed (EventData As MouseEvent)";
 //BA.debugLineNum = 471;BA.debugLine="StartLeft = ImageView1.Left";
_startleft = (int) (_imageview1.getLeft());
 //BA.debugLineNum = 472;BA.debugLine="StartTop = ImageView1.Top";
_starttop = (int) (_imageview1.getTop());
 //BA.debugLineNum = 473;BA.debugLine="StartX = EventData.X";
_startx = (int) (_eventdata.getX());
 //BA.debugLineNum = 474;BA.debugLine="StartY = EventData.Y";
_starty = (int) (_eventdata.getY());
 //BA.debugLineNum = 475;BA.debugLine="End Sub";
return "";
}
public static String  _pagination1_pagechanged(int _pageindex) throws Exception{
 //BA.debugLineNum = 666;BA.debugLine="Sub Pagination1_PageChanged (PageIndex As Int)";
 //BA.debugLineNum = 667;BA.debugLine="Log($\"Current page: ${PageIndex}\"$)";
anywheresoftware.b4a.keywords.Common.LogImpl("52031617",("Current page: "+anywheresoftware.b4a.keywords.Common.SmartStringFormatter("",(Object)(_pageindex))+""),0);
 //BA.debugLineNum = 668;BA.debugLine="End Sub";
return "";
}

private static boolean processGlobalsRun;
public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        b4j.example.dateutils._process_globals();
b4j.example.cssutils._process_globals();
main._process_globals();
utils._process_globals();
xuiviewsutils._process_globals();
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 7;BA.debugLine="Private fx As JFX";
_fx = new anywheresoftware.b4j.objects.JFX();
 //BA.debugLineNum = 8;BA.debugLine="Private MainForm As Form";
_mainform = new anywheresoftware.b4j.objects.Form();
 //BA.debugLineNum = 9;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 15;BA.debugLine="Type TextMetric(Width As Double, Height As Double";
;
 //BA.debugLineNum = 17;BA.debugLine="Type Point (x As Double, y As Double)";
;
 //BA.debugLineNum = 18;BA.debugLine="Private PrevPoint As Point";
_prevpoint = new b4j.example.main._point();
 //BA.debugLineNum = 21;BA.debugLine="Public tmr As Timer";
_tmr = new anywheresoftware.b4a.objects.Timer();
 //BA.debugLineNum = 22;BA.debugLine="Public tmrinterval As Long = 500";
_tmrinterval = (long) (500);
 //BA.debugLineNum = 23;BA.debugLine="Private Progress As Int = 0";
_progress = (int) (0);
 //BA.debugLineNum = 26;BA.debugLine="Private TabPane1 As TabPane";
_tabpane1 = new anywheresoftware.b4j.objects.TabPaneWrapper();
 //BA.debugLineNum = 27;BA.debugLine="Private TabPages(9) As TabPage";
_tabpages = new anywheresoftware.b4j.objects.TabPaneWrapper.TabWrapper[(int) (9)];
{
int d0 = _tabpages.length;
for (int i0 = 0;i0 < d0;i0++) {
_tabpages[i0] = new anywheresoftware.b4j.objects.TabPaneWrapper.TabWrapper();
}
}
;
 //BA.debugLineNum = 29;BA.debugLine="Private Accordion1 As Accordion";
_accordion1 = new anywheresoftware.b4j.objects.AccordionWrapper();
 //BA.debugLineNum = 30;BA.debugLine="Private Canvas1 As Canvas";
_canvas1 = new anywheresoftware.b4j.objects.CanvasWrapper();
 //BA.debugLineNum = 32;BA.debugLine="Private ChoiceBox1 As ChoiceBox";
_choicebox1 = new anywheresoftware.b4j.objects.ChoiceBoxWrapper();
 //BA.debugLineNum = 33;BA.debugLine="Dim bChangedFromCode As Boolean = False";
_bchangedfromcode = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 39;BA.debugLine="Private Label1 As Label";
_label1 = new anywheresoftware.b4j.objects.LabelWrapper();
 //BA.debugLineNum = 41;BA.debugLine="Private Label2 As Label";
_label2 = new anywheresoftware.b4j.objects.LabelWrapper();
 //BA.debugLineNum = 45;BA.debugLine="Private btnB01 As Button";
_btnb01 = new anywheresoftware.b4j.objects.ButtonWrapper();
 //BA.debugLineNum = 46;BA.debugLine="Private btnB02 As Button";
_btnb02 = new anywheresoftware.b4j.objects.ButtonWrapper();
 //BA.debugLineNum = 47;BA.debugLine="Private btnPane1 As Button";
_btnpane1 = new anywheresoftware.b4j.objects.ButtonWrapper();
 //BA.debugLineNum = 49;BA.debugLine="Private ColorPicker1 As ColorPicker";
_colorpicker1 = new anywheresoftware.b4j.objects.ColorPickerWrapper();
 //BA.debugLineNum = 51;BA.debugLine="Private DatePicker1 As DatePicker";
_datepicker1 = new anywheresoftware.b4j.objects.DatePickerWrapper();
 //BA.debugLineNum = 54;BA.debugLine="Private ImageView1 As ImageView";
_imageview1 = new anywheresoftware.b4j.objects.ImageViewWrapper();
 //BA.debugLineNum = 55;BA.debugLine="Private HTMLEditor1 As HTMLEditor";
_htmleditor1 = new anywheresoftware.b4j.objects.HTMLEditorWrapper();
 //BA.debugLineNum = 56;BA.debugLine="Private WebView1 As WebView";
_webview1 = new anywheresoftware.b4j.objects.WebViewWrapper();
 //BA.debugLineNum = 59;BA.debugLine="Private MB As MenuBar";
_mb = new anywheresoftware.b4j.objects.MenuItemWrapper.MenuBarWrapper();
 //BA.debugLineNum = 60;BA.debugLine="Private TableView1 As TableView";
_tableview1 = new anywheresoftware.b4j.objects.TableViewWrapper();
 //BA.debugLineNum = 61;BA.debugLine="Private Pagination1 As Pagination";
_pagination1 = new anywheresoftware.b4j.objects.PaginationWrapper();
 //BA.debugLineNum = 64;BA.debugLine="Private txtE01 As TextField";
_txte01 = new anywheresoftware.b4j.objects.TextInputControlWrapper.TextFieldWrapper();
 //BA.debugLineNum = 65;BA.debugLine="Private txtE02 As TextField";
_txte02 = new anywheresoftware.b4j.objects.TextInputControlWrapper.TextFieldWrapper();
 //BA.debugLineNum = 66;BA.debugLine="Private ListView1 As ListView";
_listview1 = new anywheresoftware.b4j.objects.ListViewWrapper();
 //BA.debugLineNum = 68;BA.debugLine="Private txtF02 As TextField";
_txtf02 = new anywheresoftware.b4j.objects.TextInputControlWrapper.TextFieldWrapper();
 //BA.debugLineNum = 69;BA.debugLine="Private txtF01 As TextField";
_txtf01 = new anywheresoftware.b4j.objects.TextInputControlWrapper.TextFieldWrapper();
 //BA.debugLineNum = 71;BA.debugLine="Private cbF01 As ComboBox";
_cbf01 = new anywheresoftware.b4j.objects.ComboBoxWrapper();
 //BA.debugLineNum = 72;BA.debugLine="Private chkF01 As CheckBox";
_chkf01 = new anywheresoftware.b4j.objects.CheckboxWrapper();
 //BA.debugLineNum = 73;BA.debugLine="Private chkF02 As CheckBox";
_chkf02 = new anywheresoftware.b4j.objects.CheckboxWrapper();
 //BA.debugLineNum = 74;BA.debugLine="Private chkF03 As CheckBox";
_chkf03 = new anywheresoftware.b4j.objects.CheckboxWrapper();
 //BA.debugLineNum = 75;BA.debugLine="Private chkF04 As CheckBox";
_chkf04 = new anywheresoftware.b4j.objects.CheckboxWrapper();
 //BA.debugLineNum = 76;BA.debugLine="Private rbF01 As RadioButton";
_rbf01 = new anywheresoftware.b4j.objects.ButtonWrapper.RadioButtonWrapper();
 //BA.debugLineNum = 77;BA.debugLine="Private rbF02 As RadioButton";
_rbf02 = new anywheresoftware.b4j.objects.ButtonWrapper.RadioButtonWrapper();
 //BA.debugLineNum = 78;BA.debugLine="Private rbF03 As RadioButton";
_rbf03 = new anywheresoftware.b4j.objects.ButtonWrapper.RadioButtonWrapper();
 //BA.debugLineNum = 79;BA.debugLine="Private rbF04 As RadioButton";
_rbf04 = new anywheresoftware.b4j.objects.ButtonWrapper.RadioButtonWrapper();
 //BA.debugLineNum = 80;BA.debugLine="Private txtF03 As TextField";
_txtf03 = new anywheresoftware.b4j.objects.TextInputControlWrapper.TextFieldWrapper();
 //BA.debugLineNum = 81;BA.debugLine="Private txtF04 As TextField";
_txtf04 = new anywheresoftware.b4j.objects.TextInputControlWrapper.TextFieldWrapper();
 //BA.debugLineNum = 83;BA.debugLine="Private ProgressBar1 As ProgressBar";
_progressbar1 = new anywheresoftware.b4j.objects.ProgressIndicatorWrapper.ProgressBarWrapper();
 //BA.debugLineNum = 84;BA.debugLine="Private Label_Progress As Label";
_label_progress = new anywheresoftware.b4j.objects.LabelWrapper();
 //BA.debugLineNum = 85;BA.debugLine="Private ProgressIndicator1 As ProgressIndicator";
_progressindicator1 = new anywheresoftware.b4j.objects.ProgressIndicatorWrapper();
 //BA.debugLineNum = 86;BA.debugLine="Private txtH01 As TextField";
_txth01 = new anywheresoftware.b4j.objects.TextInputControlWrapper.TextFieldWrapper();
 //BA.debugLineNum = 87;BA.debugLine="Private Slider1 As Slider";
_slider1 = new anywheresoftware.b4j.objects.SliderWrapper();
 //BA.debugLineNum = 88;BA.debugLine="Private PaneH01 As Pane";
_paneh01 = new anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper();
 //BA.debugLineNum = 90;BA.debugLine="Private ScrollPane1 As ScrollPane";
_scrollpane1 = new anywheresoftware.b4j.objects.ScrollPaneWrapper();
 //BA.debugLineNum = 93;BA.debugLine="Private StartLeft, StartTop, StartX, StartY As In";
_startleft = 0;
_starttop = 0;
_startx = 0;
_starty = 0;
 //BA.debugLineNum = 94;BA.debugLine="Private P_map As Pane";
_p_map = new anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper();
 //BA.debugLineNum = 95;BA.debugLine="End Sub";
return "";
}
public static String  _progresscolor(int _value) throws Exception{
 //BA.debugLineNum = 750;BA.debugLine="Sub progressColor(value As Int)";
 //BA.debugLineNum = 751;BA.debugLine="If value <= 25 Then";
if (_value<=25) { 
 //BA.debugLineNum = 752;BA.debugLine="ProgressBar1.style=\"-fx-box-border: black; -fx-a";
_progressbar1.setStyle("-fx-box-border: black; -fx-accent: green;");
 }else if(_value>25 && _value<=50) { 
 //BA.debugLineNum = 754;BA.debugLine="ProgressBar1.style=\"-fx-box-border: black; -fx-a";
_progressbar1.setStyle("-fx-box-border: black; -fx-accent: yellow;");
 }else if(_value>50 && _value<=75) { 
 //BA.debugLineNum = 756;BA.debugLine="ProgressBar1.style=\"-fx-box-border: black; -fx-a";
_progressbar1.setStyle("-fx-box-border: black; -fx-accent: orange;");
 }else {
 //BA.debugLineNum = 758;BA.debugLine="ProgressBar1.style=\"-fx-box-border: black; -fx-a";
_progressbar1.setStyle("-fx-box-border: black; -fx-accent: red;");
 };
 //BA.debugLineNum = 761;BA.debugLine="End Sub";
return "";
}
public static String  _rbf_selectedchange(boolean _selected) throws Exception{
anywheresoftware.b4j.objects.ButtonWrapper.RadioButtonWrapper _rb = null;
 //BA.debugLineNum = 539;BA.debugLine="Private Sub rbF_SelectedChange(Selected As Boolean";
 //BA.debugLineNum = 540;BA.debugLine="Dim rb As RadioButton";
_rb = new anywheresoftware.b4j.objects.ButtonWrapper.RadioButtonWrapper();
 //BA.debugLineNum = 542;BA.debugLine="rb = Sender";
_rb = (anywheresoftware.b4j.objects.ButtonWrapper.RadioButtonWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.ButtonWrapper.RadioButtonWrapper(), (javafx.scene.control.RadioButton)(anywheresoftware.b4a.keywords.Common.Sender(ba)));
 //BA.debugLineNum = 544;BA.debugLine="Log(rb.text)";
anywheresoftware.b4a.keywords.Common.LogImpl("51769477",_rb.getText(),0);
 //BA.debugLineNum = 545;BA.debugLine="If Selected Then";
if (_selected) { 
 //BA.debugLineNum = 546;BA.debugLine="Log(rb.text)";
anywheresoftware.b4a.keywords.Common.LogImpl("51769479",_rb.getText(),0);
 };
 //BA.debugLineNum = 550;BA.debugLine="End Sub";
return "";
}
public static Object  _scrollchanged_event(String _methodname,Object[] _args) throws Exception{
anywheresoftware.b4j.object.JavaObject _ev = null;
float _delta = 0f;
float _zoom = 0f;
 //BA.debugLineNum = 485;BA.debugLine="Private Sub ScrollChanged_Event (MethodName As Str";
 //BA.debugLineNum = 486;BA.debugLine="If MethodName = \"handle\" Then";
if ((_methodname).equals("handle")) { 
 //BA.debugLineNum = 487;BA.debugLine="Dim ev As JavaObject = Args(0)";
_ev = new anywheresoftware.b4j.object.JavaObject();
_ev = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_args[(int) (0)]));
 //BA.debugLineNum = 488;BA.debugLine="Dim delta As Float = ev.RunMethod(\"getDeltaY\", N";
_delta = (float)(BA.ObjectToNumber(_ev.RunMethod("getDeltaY",(Object[])(anywheresoftware.b4a.keywords.Common.Null))));
 //BA.debugLineNum = 489;BA.debugLine="Dim Zoom As Float";
_zoom = 0f;
 //BA.debugLineNum = 490;BA.debugLine="If delta > 0 Then";
if (_delta>0) { 
 //BA.debugLineNum = 491;BA.debugLine="Zoom = 1.1";
_zoom = (float) (1.1);
 }else {
 //BA.debugLineNum = 493;BA.debugLine="Zoom = 0.9";
_zoom = (float) (0.9);
 };
 //BA.debugLineNum = 495;BA.debugLine="ZoomChanged(ev.RunMethod(\"getX\", Null), ev.RunMe";
_zoomchanged((int)(BA.ObjectToNumber(_ev.RunMethod("getX",(Object[])(anywheresoftware.b4a.keywords.Common.Null)))),(int)(BA.ObjectToNumber(_ev.RunMethod("getY",(Object[])(anywheresoftware.b4a.keywords.Common.Null)))),_zoom);
 };
 //BA.debugLineNum = 497;BA.debugLine="Return Null";
if (true) return anywheresoftware.b4a.keywords.Common.Null;
 //BA.debugLineNum = 498;BA.debugLine="End Sub";
return null;
}
public static String  _slider1_valuechange(double _value) throws Exception{
 //BA.debugLineNum = 771;BA.debugLine="Private Sub Slider1_ValueChange (Value As Double)";
 //BA.debugLineNum = 772;BA.debugLine="txtH01.Text = Slider1.Value";
_txth01.setText(BA.NumberToString(_slider1.getValue()));
 //BA.debugLineNum = 773;BA.debugLine="End Sub";
return "";
}
public static String  _tabpane_settabclosingpolicy(anywheresoftware.b4j.objects.TabPaneWrapper _pane,String _policy) throws Exception{
anywheresoftware.b4j.object.JavaObject _jotp = null;
anywheresoftware.b4j.object.JavaObject _jotcp = null;
 //BA.debugLineNum = 282;BA.debugLine="Sub TabPane_SetTabClosingPolicy(Pane As TabPane, P";
 //BA.debugLineNum = 283;BA.debugLine="Dim joTP As JavaObject = Pane";
_jotp = new anywheresoftware.b4j.object.JavaObject();
_jotp = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_pane.getObject()));
 //BA.debugLineNum = 284;BA.debugLine="Dim joTCP As JavaObject";
_jotcp = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 285;BA.debugLine="joTCP.InitializeStatic(\"javafx.scene.control.TabP";
_jotcp.InitializeStatic("javafx.scene.control.TabPane.TabClosingPolicy");
 //BA.debugLineNum = 286;BA.debugLine="If Policy.Length = 0 Then Policy = \"ALL_TABS\"";
if (_policy.length()==0) { 
_policy = "ALL_TABS";};
 //BA.debugLineNum = 287;BA.debugLine="joTP.RunMethod(\"setTabClosingPolicy\", Array(joTCP";
_jotp.RunMethod("setTabClosingPolicy",new Object[]{_jotcp.GetField(_policy.toUpperCase())});
 //BA.debugLineNum = 288;BA.debugLine="End Sub";
return "";
}
public static Object  _tabpane_tools_close_event(String _eventname,Object[] _args) throws Exception{
anywheresoftware.b4j.object.JavaObject _ceventjo = null;
anywheresoftware.b4j.objects.TabPaneWrapper.TabWrapper _tp = null;
 //BA.debugLineNum = 272;BA.debugLine="Sub TabPane_Tools_Close_Event(EventName As String,";
 //BA.debugLineNum = 273;BA.debugLine="Dim CEventJO As JavaObject = Args(0)";
_ceventjo = new anywheresoftware.b4j.object.JavaObject();
_ceventjo = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_args[(int) (0)]));
 //BA.debugLineNum = 274;BA.debugLine="Dim tp As TabPage = CEventJO.RunMethodJO(\"getSour";
_tp = new anywheresoftware.b4j.objects.TabPaneWrapper.TabWrapper();
_tp = (anywheresoftware.b4j.objects.TabPaneWrapper.TabWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.TabPaneWrapper.TabWrapper(), (javafx.scene.control.Tab)(_ceventjo.RunMethodJO("getSource",(Object[])(anywheresoftware.b4a.keywords.Common.Null)).getObject()));
 //BA.debugLineNum = 275;BA.debugLine="TabPages(tp.id).Tag = 0";
_tabpages[(int)(Double.parseDouble(_tp.getId()))].setTag((Object)(0));
 //BA.debugLineNum = 276;BA.debugLine="Log($\"Closed Tab with ID ${tp.id} and text '${tp.";
anywheresoftware.b4a.keywords.Common.LogImpl("5327684",("Closed Tab with ID "+anywheresoftware.b4a.keywords.Common.SmartStringFormatter("",(Object)(_tp.getId()))+" and text '"+anywheresoftware.b4a.keywords.Common.SmartStringFormatter("",(Object)(_tp.getText()))+"' (#Tabs "+anywheresoftware.b4a.keywords.Common.SmartStringFormatter("",(Object)(_tabpane1.getTabs().getSize()))+")."),0);
 //BA.debugLineNum = 277;BA.debugLine="Return False";
if (true) return (Object)(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 278;BA.debugLine="End Sub";
return null;
}
public static String  _tabpane1_mouseclicked(anywheresoftware.b4j.objects.NodeWrapper.MouseEventWrapper _eventdata) throws Exception{
 //BA.debugLineNum = 265;BA.debugLine="Private Sub TabPane1_MouseClicked (EventData As Mo";
 //BA.debugLineNum = 267;BA.debugLine="End Sub";
return "";
}
public static String  _tabpane1_tabchanged(anywheresoftware.b4j.objects.TabPaneWrapper.TabWrapper _selectedtab) throws Exception{
 //BA.debugLineNum = 259;BA.debugLine="Private Sub TabPane1_TabChanged (SelectedTab As Ta";
 //BA.debugLineNum = 261;BA.debugLine="Log(\"TabPane1_目前選擇的頁面: \"&TabPane1.SelectedIndex)";
anywheresoftware.b4a.keywords.Common.LogImpl("5196610","TabPane1_目前選擇的頁面: "+BA.NumberToString(_tabpane1.getSelectedIndex()),0);
 //BA.debugLineNum = 262;BA.debugLine="Log($\"Selected tab = ${SelectedTab.Text}\"$)";
anywheresoftware.b4a.keywords.Common.LogImpl("5196611",("Selected tab = "+anywheresoftware.b4a.keywords.Common.SmartStringFormatter("",(Object)(_selectedtab.getText()))+""),0);
 //BA.debugLineNum = 263;BA.debugLine="End Sub";
return "";
}
public static String  _textfield_action() throws Exception{
anywheresoftware.b4j.objects.TextInputControlWrapper.TextFieldWrapper _txt = null;
 //BA.debugLineNum = 720;BA.debugLine="Private Sub TextField_Action";
 //BA.debugLineNum = 721;BA.debugLine="Log(\"TextField_Action==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("52293761","TextField_Action==>",0);
 //BA.debugLineNum = 722;BA.debugLine="Dim txt As TextField";
_txt = new anywheresoftware.b4j.objects.TextInputControlWrapper.TextFieldWrapper();
 //BA.debugLineNum = 723;BA.debugLine="txt = Sender";
_txt = (anywheresoftware.b4j.objects.TextInputControlWrapper.TextFieldWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.TextInputControlWrapper.TextFieldWrapper(), (javafx.scene.control.TextField)(anywheresoftware.b4a.keywords.Common.Sender(ba)));
 //BA.debugLineNum = 725;BA.debugLine="Log(txt.tag)";
anywheresoftware.b4a.keywords.Common.LogImpl("52293765",BA.ObjectToString(_txt.getTag()),0);
 //BA.debugLineNum = 726;BA.debugLine="txt.Text = \"test\"";
_txt.setText("test");
 //BA.debugLineNum = 729;BA.debugLine="End Sub";
return "";
}
public static void  _tmr_tick() throws Exception{
ResumableSub_tmr_Tick rsub = new ResumableSub_tmr_Tick(null);
rsub.resume(ba, null);
}
public static class ResumableSub_tmr_Tick extends BA.ResumableSub {
public ResumableSub_tmr_Tick(b4j.example.main parent) {
this.parent = parent;
}
b4j.example.main parent;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 734;BA.debugLine="Progress = Progress + 10";
parent._progress = (int) (parent._progress+10);
 //BA.debugLineNum = 735;BA.debugLine="progressColor(Progress)";
_progresscolor(parent._progress);
 //BA.debugLineNum = 737;BA.debugLine="ProgressBar1.Progress = Progress / 100";
parent._progressbar1.setProgress(parent._progress/(double)100);
 //BA.debugLineNum = 739;BA.debugLine="ProgressIndicator1.Progress = Progress / 100";
parent._progressindicator1.setProgress(parent._progress/(double)100);
 //BA.debugLineNum = 741;BA.debugLine="Label1.Text = $\"Progress ${Progress}%\"$";
parent._label1.setText(("Progress "+anywheresoftware.b4a.keywords.Common.SmartStringFormatter("",(Object)(parent._progress))+"%"));
 //BA.debugLineNum = 742;BA.debugLine="Label_Progress.Text = $\"${NumberFormat(Progress,0";
parent._label_progress.setText((""+anywheresoftware.b4a.keywords.Common.SmartStringFormatter("",(Object)(anywheresoftware.b4a.keywords.Common.NumberFormat(parent._progress,(int) (0),(int) (0))))+"%"));
 //BA.debugLineNum = 743;BA.debugLine="Sleep(0)";
anywheresoftware.b4a.keywords.Common.Sleep(ba,this,(int) (0));
this.state = 5;
return;
case 5:
//C
this.state = 1;
;
 //BA.debugLineNum = 744;BA.debugLine="If Progress = 100 Then";
if (true) break;

case 1:
//if
this.state = 4;
if (parent._progress==100) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 745;BA.debugLine="tmr.Enabled = False";
parent._tmr.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 746;BA.debugLine="Label1.Text = $\"Task completed.\"$";
parent._label1.setText(("Task completed."));
 if (true) break;

case 4:
//C
this.state = -1;
;
 //BA.debugLineNum = 748;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public static String  _txtf03_textchanged(String _old,String _new) throws Exception{
 //BA.debugLineNum = 660;BA.debugLine="Private Sub txtF03_TextChanged (Old As String, New";
 //BA.debugLineNum = 661;BA.debugLine="txtF04.text = txtF03.text";
_txtf04.setText(_txtf03.getText());
 //BA.debugLineNum = 662;BA.debugLine="End Sub";
return "";
}
public static String  _zoomchanged(int _x,int _y,float _zoomdelta) throws Exception{
float _ivx = 0f;
float _ivy = 0f;
 //BA.debugLineNum = 500;BA.debugLine="Private Sub ZoomChanged (x As Int, y As Int, ZoomD";
 //BA.debugLineNum = 501;BA.debugLine="Dim ivx As Float = x - ImageView1.Left";
_ivx = (float) (_x-_imageview1.getLeft());
 //BA.debugLineNum = 502;BA.debugLine="Dim ivy As Float = y - ImageView1.Top";
_ivy = (float) (_y-_imageview1.getTop());
 //BA.debugLineNum = 503;BA.debugLine="ZoomDelta = Max(ZoomDelta, P_map.Width / ImageVie";
_zoomdelta = (float) (anywheresoftware.b4a.keywords.Common.Max(_zoomdelta,_p_map.getWidth()/(double)_imageview1.getWidth()));
 //BA.debugLineNum = 504;BA.debugLine="ImageView1.SetLayoutAnimated(0, x - ivx * ZoomDel";
_imageview1.SetLayoutAnimated((int) (0),_x-_ivx*_zoomdelta,_y-_ivy*_zoomdelta,_imageview1.getWidth()*_zoomdelta,_imageview1.getHeight()*_zoomdelta);
 //BA.debugLineNum = 505;BA.debugLine="End Sub";
return "";
}
}
